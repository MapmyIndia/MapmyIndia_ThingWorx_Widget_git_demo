TW.IDE.Widgets.mmi_map = function () {
    this.widgetIconUrl = function () {
        return  "../Common/extensions/MMI_Widgets_ExtensionPackage/ui/mmi_map/mmi_map_icon.jpg";
    }
    var thisWidget = this;

    this.widgetProperties = function () {
        return {
            'name': 'MapMyIndia Map',
            'description': 'Provide MAP related functionalities.',
            'category': ['Data'],
            'iconImage': 'mmi_map.ide.png',
            'isExtension': true,
            'supportsAutoResize': true,
            'defaultBindingTargetProperty': 'Data',
            'properties': {
                'Data': {
                    'description': 'Data source',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                'LocationField': {
                    'description': 'Field which will provide location information for markers/tracks',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'defaultValue': 'location',
                    'sourcePropertyName': 'Data',
                    'baseTypeRestriction': 'LOCATION',
                    'baseType': 'FIELDNAME'
                },
                'MarkerField': {
                    'description': 'Field which will provide icon information for markers',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'defaultValue': '',
                    'sourcePropertyName': 'Data',
                    'baseTypeRestriction': 'IMAGELINK',
                    'baseType': 'FIELDNAME'
                },
                'MarkerLayerField': {
                    'description': 'Field which will provide layer information for markers/tracks',
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'Data',
                    'baseTypeRestriction': 'NUMBER',
                    'baseType': 'FIELDNAME'
                },
                'ShowMarkerTooltips': {
                    'description': 'Show marker tooltips',
                    'defaultValue': true,
                    'isBindingTarget': true,
                    'baseType': 'BOOLEAN'
                },
                'TooltipField1': {
                    'description': 'Field which will provide 1st tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'Data',
                    'baseType': 'FIELDNAME'
                },
                'TooltipLabel1': {
                    'description': 'Optional 1st tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'TooltipField2': {
                    'description': 'Field which will provide 2nd tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'Data',
                    'baseType': 'FIELDNAME'
                },
                'TooltipLabel2': {
                    'description': 'Optional 2nd tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'TooltipField3': {
                    'description': 'Field which will provide 3rd tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'Data',
                    'baseType': 'FIELDNAME'
                },
                'TooltipLabel3': {
                    'description': 'Optional 3rd tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'TooltipField4': {
                    'description': 'Field which will provide 4th tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'Data',
                    'baseType': 'FIELDNAME'
                },
                'TooltipLabel4': {
                    'description': 'Optional 4th tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'RouteData': {
                    'description': 'Route data source',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'RouteLocationField': {
                    'description': 'Field which will provide location information for route',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'defaultValue': 'location',
                    'sourcePropertyName': 'RouteData',
                    'baseTypeRestriction': 'LOCATION',
                    'baseType': 'FIELDNAME'
                },
                'PlannedRouteData': {
                    'description': 'Planned route data source',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'PlannedRouteLocationField': {
                    'description': 'Field which will provide location information for the planned route',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'defaultValue': 'location',
                    'sourcePropertyName': 'PlannedRouteData',
                    'baseTypeRestriction': 'LOCATION',
                    'baseType': 'FIELDNAME'
                },
                'RegionData': {
                    'description': 'Region data source',
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'isVisible': true,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'CircularRegionData': {
                    'description': 'Circular Region data source',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'RegionLocationData': {
                    'description': 'Region location data source',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': false
                },
                'RegionLocationField': {
                    'description': 'Field which will provide location information for region',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'defaultValue': 'location',
                    'sourcePropertyName': 'RegionLocationData',
                    'baseTypeRestriction': 'LOCATION',
                    'baseType': 'FIELDNAME'
                },
                'CircularRegionLocationField': {
                    'description': 'Field which will provide location information for region',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'defaultValue': 'location',
                    'sourcePropertyName': 'CircularRegionData',
                    'baseTypeRestriction': 'LOCATION',
                    'baseType': 'FIELDNAME'
                },


                'CircleRadiusField': {
                    'description': 'Field which will provide radius information for circular region',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'defaultValue': 'radius',
                    'sourcePropertyName': 'CircularRegionData',
                    'baseTypeRestriction': 'INTEGER',
                    'baseType': 'FIELDNAME'
                },
                'RegionLocationsField': {
                    'description': 'Field which will provide location table information for region',
                    'isBindingTarget': false,
                    'isVisible': true,
                    'isEditable': true,
                    'defaultValue': 'locations',
                    'sourcePropertyName': 'RegionData',
                    'baseTypeRestriction': 'INFOTABLE',
                    'baseType': 'FIELDNAME'
                },
                'RegionLayerField': {
                    'description': 'Field which will provide layer information for regions',
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'RegionData',
                    'baseTypeRestriction': 'NUMBER',
                    'baseType': 'FIELDNAME'
                },
                'ShowRegionTooltips': {
                    'description': 'Show region tooltips',
                    'defaultValue': false,
                    'isBindingTarget': true,
                    'baseType': 'BOOLEAN'
                },
                'ShowCircularRegionTooltips': {
                    'description': 'Show region tooltips',
                    'defaultValue': false,
                    'isBindingTarget': true,
                    'baseType': 'BOOLEAN'
                },
                'RegionTooltipField1': {
                    'description': 'Region field which will provide 1st tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'RegionData',
                    'baseType': 'FIELDNAME'
                },
                'RegionTooltipLabel1': {
                    'description': 'Optional 1st tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'RegionTooltipField2': {
                    'description': 'Region field which will provide 2nd tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'RegionData',
                    'baseType': 'FIELDNAME'
                },
                'RegionTooltipLabel2': {
                    'description': 'Optional 2nd tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'RegionTooltipField3': {
                    'description': 'Region field which will provide 3rd tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'RegionData',
                    'baseType': 'FIELDNAME'
                },
                'RegionTooltipLabel3': {
                    'description': 'Optional 3rd tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'RegionTooltipField4': {
                    'description': 'Region field which will provide 4th tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'RegionData',
                    'baseType': 'FIELDNAME'
                },
                'RegionTooltipLabel4': {
                    'description': 'Optional 4th tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'RegionFillOpacity': {
                    'description': 'Field which will provide opacity for region',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'defaultValue': 1.0,
                    'baseType': 'NUMBER'
                },
                'CircularRegionTooltipField1': {
                    'description': 'Region field which will provide 1st tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'CircularRegionData',
                    'baseType': 'FIELDNAME'
                },
                'CircularRegionTooltipLabel1': {
                    'description': 'Optional 1st tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'CircularRegionTooltipField2': {
                    'description': 'Region field which will provide 2nd tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'CircularRegionData',
                    'baseType': 'FIELDNAME'
                },
                'CircularRegionTooltipLabel2': {
                    'description': 'Optional 2nd tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'CircularRegionTooltipField3': {
                    'description': 'Region field which will provide 3rd tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'CircularRegionData',
                    'baseType': 'FIELDNAME'
                },
                'CircularRegionTooltipLabel3': {
                    'description': 'Optional 3rd tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'CircularRegionTooltipField4': {
                    'description': 'Region field which will provide 4th tooltip data',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'sourcePropertyName': 'CircularRegionData',
                    'baseType': 'FIELDNAME'
                },
                'CircularRegionTooltipLabel': {
                    'description': 'Optional 4th tooltip label',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'baseType': 'STRING',
                    'isLocalizable': true
                },
                'CircularRegionFillOpacity': {
                    'description': 'Field which will provide opacity for region',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'isEditable': true,
                    'defaultValue': 1.0,
                    'baseType': 'NUMBER'
                },
                'SelectedLocation': {
                    'description': 'Currently selected location',
                    'isEditable': true,
                    'isBindingSource': true,
                    'isBindingTarget': true,
                    'baseType': 'LOCATION'
                },
                'CurrentZoom': {
                    'description': 'Map zoom level (ranges from 1 to 15)',
                    'isBindingSource': true,
                    'baseType': 'NUMBER'
                },
                'Zoom': {
                    'description': 'Map zoom level (ranges from 1 to 15)',
                    'isBindingTarget': true,
                    'baseType': 'NUMBER',
                    'defaultValue': 8
                },
                'AutoZoomBehavior': {
                    'isBindingTarget': false,
                    'description': 'When to trigger AutoZoom',
                    'baseType': 'STRING',
                    'defaultValue': 'every-data-change',
                    'selectOptions': [
                        {value: 'every-data-change', text: 'AutoZoom every time any data refreshes'},
                        {value: 'only-when-autozoom-invoked', text: 'AutoZoom only when AutoZoom widget service is invoked'},
                        {value: 'disable-on-user-pan-zoom', text: 'AutoZoom on data refresh, but disable AutoZoom if user manually pans or zooms'},
                        {value: 'only-initial-data', text: 'AutoZoom on initial data only (useful if you use BoundsChanged to retrieve new data)'}
                    ]
                },
                'MarkerFormatting': {
                    'description': 'Optional rules for dynamic formatting of map markers',
                    'baseType': 'STATEFORMATTING',
                    'baseTypeInfotableProperty': 'Data',
                    'isVisible': true
                },
                'MarkerStyle': {
                    'description': 'Style formatting of map markers',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'defaultValue': 'DefaultMapMarkerStyle'
                },
                'SelectedMarkerStyle': {
                    'description': 'Style formatting of selected map markers',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultMapSelectedStyle'
                },
                'SelectionMarkerStyle': {
                    'description': 'Style formatting of current map selection',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultMapSelectionStyle'
                },
                'StartMarkerStyle': {
                    'description': 'Style formatting of starting map marker for paths/tracks',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultMapStartStyle'
                },
                'EndMarkerStyle': {
                    'description': 'Style formatting of ending map marker for paths/tracks',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultMapEndStyle'
                },
                'PathStyle': {
                    'description': 'Style formatting of line for paths/tracks',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'defaultValue': 'DefaultMapPathStyle'
                },
                'RouteStyle': {
                    'description': 'Style formatting of line for routes',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'defaultValue': 'DefaultMapRouteStyle'
                },
                'PlannedRouteStyle': {
                    'description': 'Style formatting of line for planned routes',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'defaultValue': 'DefaultMapRouteStyle'
                },
                'RegionFormatting': {
                    'description': 'Optional rules for dynamic formatting of map regions',
                    'baseType': 'STATEFORMATTING',
                    'baseTypeInfotableProperty': 'RegionData',
                    'isVisible': true
                },
                'CircularRegionFormatting': {
                    'description': 'Optional rules for dynamic formatting of map regions',
                    'baseType': 'STATEFORMATTING',
                    'baseTypeInfotableProperty': 'CircularRegionData',
                    'isVisible': true
                },
                'CircularRegionStyle': {
                    'description': 'Style formatting of line for regions',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'defaultValue': 'DefaultMapRegionStyle'
                },
                'SelectedRegionStyle': {
                    'description': 'Style formatting of selected regions',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultMapRegionSelectedStyle'
                },
                'SelectedCircularRegionStyle': {
                    'description': 'Style formatting of selected regions',
                    'baseType': 'STYLEDEFINITION',
                    'defaultValue': 'DefaultMapRegionSelectedStyle'
                },
                'ShowMarkers': {
                    'description': 'Show map markers',
                    'defaultValue': true,
                    'isBindingTarget': true,
                    'baseType': 'BOOLEAN'
                },
                'ShowPathBetweenMarkers': {
                    'description': 'Show path/tracks between markers (ordered by the order in the underlying data)',
                    'isBindingTarget': true,
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'ShowStartMarker': {
                    'description': 'Show special marker for first map data point',
                    'isBindingTarget': true,
                    'defaultValue': true,
                    'baseType': 'BOOLEAN'
                },
                'ShowEndMarker': {
                    'description': 'Show special marker for last map data point',
                    'isBindingTarget': true,
                    'defaultValue': true,
                    'baseType': 'BOOLEAN'
                },
                'ShowRoute': {
                    'description': 'Show route',
                    'defaultValue': false,
                    'isBindingTarget': true,
                    'baseType': 'BOOLEAN'
                },
                'ShowPlannedRoute': {
                    'description': 'Show planned route',
                    'defaultValue': false,
                    'isBindingTarget': true,
                    'baseType': 'BOOLEAN'
                },
                'ShowRegions': {
                    'description': 'Show regions',
                    'defaultValue': false,
                    'isBindingTarget': true,
                    'baseType': 'BOOLEAN'
                },
                'ShowCircularRegions': {
                    'description': 'Show regions',
                    'defaultValue': false,
                    'isBindingTarget': true,
                    'baseType': 'BOOLEAN'
                },
                'EnableLocationSelection': {
                    'description': 'Enable location selection mode',
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'ShowSelectionMarker': {
                    'description': 'Show the current selection marker',
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'EnableMarkerSelection': {
                    'description': 'Enable marker selection mode',
                    'defaultValue': true,
                    'baseType': 'BOOLEAN'
                },
                'EnableRegionSelection': {
                    'description': 'Enable regionselection mode',
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'EnableCircularRegionSelection': {
                    'description': 'Enable regionselection mode',
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'MultiSelect': {
                    'description': 'Enable multiple marker selection',
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'RegionMultiSelect': {
                    'description': 'Enable multiple region selection',
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'CircularRegionMultiSelect': {
                    'description': 'Enable multiple region selection',
                    'defaultValue': false,
                    'baseType': 'BOOLEAN'
                },
                'MashupParameters': {
                    isVisible: false,
                    'baseType': 'VALUES'
                },
                'TooltipMashupName': {
                    'isBindingTarget': true,
                    'defaultValue': '',
                    'baseType': 'MASHUPNAME'
                },
                'TooltipMashupWidth': {
                    //isVisible: false,
                    'defaultValue': 400,
                    'baseType': 'NUMBER'
                },
                'TooltipMashupHeight': {
                    //isVisible: false,
                    'defaultValue': 300,
                    'baseType': 'NUMBER'
                },
                'NEBoundary': {
                    'description': 'The northeast boundary location - Longitude, Latitude, Elevation, and Units in WGS84',
                    'isBindingSource': true,
                    'isEditable': false,
                    'isVisible': true,
                    'defaultValue': undefined,
                    'baseType': 'LOCATION'
                },
                'NWBoundary': {
                    'description': 'The northwest boundary location - Longitude, Latitude, Elevation, and Units in WGS84',
                    'isBindingSource': true,
                    'isEditable': false,
                    'isVisible': true,
                    'defaultValue': undefined,
                    'baseType': 'LOCATION'
                },
                'SEBoundary': {
                    'description': 'The southeast boundary location - Longitude, Latitude, Elevation, and Units in WGS84',
                    'isBindingSource': true,
                    'isEditable': false,
                    'isVisible': true,
                    'defaultValue': undefined,
                    'baseType': 'LOCATION'
                },
                'SWBoundary': {
                    'description': 'The southwest boundary location - Longitude, Latitude, Elevation, and Units in WGS84',
                    'isBindingSource': true,
                    'isEditable': false,
                    'isVisible': true,
                    'defaultValue': undefined,
                    'baseType': 'LOCATION'
                },
                'Width': {
                    'description': 'Widget width',
                    'defaultValue': 400
                },
                'Height': {
                    'description': 'Widget height',
                    'defaultValue': 200
                },
                Notify_data: {
                    'description': 'Notifications Data source',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                Notify_Layout: {
                    'isBindingTarget': false,
                    'description': 'Set position of notification window',
                    'baseType': 'STRING',
                    'defaultValue': 'topCenter',
                    'selectOptions': [
                        {value: 'top', text: 'Top'},
                        {value: 'topLeft', text: 'Top Left'},
                        {value: 'topCenter', text: 'Top Center'},
                        {value: 'topRight', text: 'Top Right'},
                        {value: 'center', text: 'Center'},
                        {value: 'centerLeft', text: 'Center Left'},
                        {value: 'centerRight', text: 'Center Right'},
                        {value: 'bottom', text: 'Bottom'},
                        {value: 'bottomLeft', text: 'Bottom Left'},
                        {value: 'bottomCenter', text: 'Bottom Center'},
                        {value: 'bottomRight', text: 'Bottom Right'}
                    ]
                },
                'Notify_Timeout': {
                    'description': 'Time in milliseconds after which notification hide. Set -1 if timeout not required',
                    'isBindingSource': true,
                    'isEditable': true,
                    'isVisible': true,
                    'defaultValue': 5000,
                    'baseType': 'INTEGER'
                },
                'Notify_Type_Field': {
                    'description': 'Notification type alert/error/success.',
                    'isBindingTarget': true,
                    'defaultValue': 'notifyType',
                    'sourcePropertyName': 'Notify_data',
                    'baseTypeRestriction': 'STRING',
                    'baseType': 'FIELDNAME'
                },
                'Notify_Text_Field': {
                    'description': 'Notification Text.',
                    'isBindingTarget': true,
                    'defaultValue': 'notifyText',
                    'sourcePropertyName': 'Notify_data',
                    'baseTypeRestriction': 'STRING',
                    'baseType': 'FIELDNAME'
                },
                'Notify_Success_Style': {
                    'description': 'Style formatting of success notification',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'defaultValue': 'DefaultChartStyle5'
                },
                'Notify_Error_Style': {
                    'description': 'Style formatting of error notification',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'defaultValue': 'DefaultChartStyle4'
                },
                'Notify_Normal_Style': {
                    'description': 'Style formatting of normal notification',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'isBindingTarget': true,
                    'isBindingSource': true,
                    'defaultValue': 'DefaultChartStyle7'
                },
                'Route_DeviationDistance': {
                    'description': 'Distance in meters after which vehicle is said to be not on route.',
                    'isBindingSource': true,
                    'isEditable': true,
                    'isVisible': true,
                    'defaultValue': 100,
                    'baseType': 'INTEGER'
                },
                'Route_DeviationMessage': {
                    'description': 'Message to display if deviation found.',
                    'isBindingSource': true,
                    'isEditable': true,
                    'isVisible': true,
                    'defaultValue': 'Vehicle deviated from route!!',
                    'baseType': 'STRING'
                },
                ShowMapTooltips: {
                    'description': 'Show map tooltips',
                    'defaultValue': true,
                    'isBindingTarget': true,
                    'baseType': 'BOOLEAN'
                },
                MaxTooltipsInVisibleArea: {
                    'description': 'Limit the number of tooltips plotted in visible area of map.',
                    'isEditable': true,
                    'isVisible': true,
                    'defaultValue': 100,
                    'baseType': 'INTEGER'
                },
                ToolTip_data: {
                    'description': 'Tooltip to be added on map Data source',
                    'isBindingTarget': true,
                    'isVisible': true,
                    'baseType': 'INFOTABLE',
                    'warnIfNotBoundAsTarget': true
                },
                ToolTip_Text_Field: {
                    'description': 'Tooltip Text.',
                    'isBindingTarget': true,
                    'defaultValue': 'tooltiptext',
                    'sourcePropertyName': 'ToolTip_data',
                    'baseTypeRestriction': 'STRING',
                    'baseType': 'FIELDNAME'
                },
                ToolTip_Location_Field: {
                    'description': 'Tooltip Location.',
                    'isBindingTarget': true,
                    'defaultValue': 'location',
                    'sourcePropertyName': 'ToolTip_data',
                    'baseTypeRestriction': 'STRING',
                    'baseType': 'FIELDNAME'
                },
                ToolTip_Image_Field: {
                    'description': 'Image to be shown.',
                    'isBindingTarget': true,
                    'defaultValue': 'tooltipimage',
                    'sourcePropertyName': 'ToolTip_data',
                    'baseTypeRestriction': 'STRING',
                    'baseType': 'FIELDNAME'
                },
                'CenterOfPolygon': {
                    'description': 'CenterOfPolygon.',
                    'isBindingTarget': true,
                    'defaultValue': 'centerLocation',
                    'sourcePropertyName': 'RegionData',
                    'baseTypeRestriction': 'STRING',
                    'baseType': 'FIELDNAME'
                },
                'CenterOfPolygonStyle': {
                    'description': 'Style formatting of CenterOfPolygon marker',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'defaultValue': 'DefaultMapMarkerStyle'
                },
                'CenterOfCircleStyle': {
                    'description': 'Style formatting of CenterOfCircle marker',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'defaultValue': 'DefaultMapMarkerStyle'
                },
                isPolygonEditable: {
                    'description': 'Show map tooltips',
                    'defaultValue': false,
                    'isBindingTarget': true,
                    'baseType': 'BOOLEAN'
                },
                'editablePolygonVertexStyle': {
                    'description': 'Style formatting of map markers',
                    'baseType': 'STYLEDEFINITION',
                    'isVisible': true,
                    'defaultValue': 'DefaultMapMarkerStyle'
                }
            }
        };
    };

    this.widgetServices = function () {
        return {
//            'AutoZoom': {'warnIfNotBound': false},
//            'MMI_FN': {'warnIfNotBound': false}
        };
    };

    this.widgetEvents = function () {
        return {
            'Changed': {},
            'DoubleClicked': {},
            'BoundsChanged': {}
        };
    };

    this.renderHtml = function () {
        var html = '';
        html += '<div class="widget-content widget-mmi_map-designer"></div>';
        return html;
    };


    this.afterAddBindingSource = function (bindingInfo) {
        if (bindingInfo['targetProperty'] === 'Data') {
            this.resetPropertyToDefaultValue('MarkerFormatting');
        }
    };

    this.afterLoad = function () {
        if (this.getProperty('EnableAutoZoom') !== undefined) {
            if (this.getProperty('EnableAutoZoom') === false) {
                this.setProperty('AutoZoomBehavior', 'only-when-autozoom-invoked');
            } else {
                this.setProperty('AutoZoomBehavior', 'every-data-change');
            }
            delete this.properties['EnableAutoZoom'];
        }
        setTimeout(function () {
            var mashupName = thisWidget.getProperty('TooltipMashupName');
            thisWidget.loadMashupParameters(mashupName, false /* isManuallyBeingSetNow */);
        }, 1000);
    };

    this.afterSetProperty = function (name, value) {
        var refreshHtml = false;
        switch (name) {
            case 'TooltipMashupName':
                if (value === undefined || value.length === 0) {
                    var allWidgetProps = thisWidget.allWidgetProperties();
                    var existingParmDefs = thisWidget.properties['MashupParameters'] || [];
                    // delete existing parameters from currentParameterDefs, widgetProperties and properties
                    for (var i = 0; i < existingParmDefs.length; i++) {
                        delete allWidgetProps.properties[existingParmDefs[i].ParameterName];
                    }

                    thisWidget.properties['MashupParameters'] = [];
                    thisWidget.properties['TooltipMashupWidth'] = undefined;
                    thisWidget.properties['TooltipMashupHeight'] = undefined;
                    thisWidget.updatedProperties();
                    refreshHtml = true;
                } else {
                    thisWidget.loadMashupParameters(value, true /* isManuallyBeingSetNow */);
                    thisWidget.updatedProperties();
                    refreshHtml = true;
                }
                break;
            default:
                break;
        }
        return refreshHtml;
    };

    this.loadMashupParameters = function (mashupName, isManuallyBeingSetNow) {
        $.ajax({
            url: "/Thingworx/Mashups/" + thisWidget.getProperty('TooltipMashupName') + '?Accept=application/json',
            type: "GET",
            datatype: "json",
            cache: false,
            async: false,
            error: function (xhr, status) {
                TW.log.error('could not load mashup "' + thisWidget.getProperty('TooltipMashupName') + '"');
            },
            complete: function (xhr, status) {
                xhr.onreadystatechange = null;
                xhr.abort = null;
                delete xhr.onreadystatechange;
                delete xhr.abort;
                xhr = null;
            },
            success: function (data) {

                var allWidgetProps = thisWidget.allWidgetProperties();
                var parmDefsForThisMashup = data.parameterDefinitions;

                var existingParmDefs = thisWidget.properties['MashupParameters'] || [];
                // delete existing parameters from currentParameterDefs, widgetProperties and properties
                for (var i = 0; i < existingParmDefs.length; i++) {
                    delete allWidgetProps.properties[existingParmDefs[i].ParameterName];
                }

                thisWidget.properties['MashupParameters'] = [];

                if (parmDefsForThisMashup !== undefined) {
                    // add the new ones in to currentParameterDefs, widgetProperties and properties
                    for (var x in parmDefsForThisMashup) {
                        parmDef = parmDefsForThisMashup[x];

                        var name = parmDef.name;
                        var description = parmDef.description;
                        var basetype = parmDef.baseType;
                        var defaultValue = parmDef.aspects.defaultValue;

                        allWidgetProps.properties[name] = {
                            'type': "property",
                            'description': description,
                            'isVisible': true,
                            'defaultValue': defaultValue,
                            'sourcePropertyName': 'Data',
                            //'baseTypeRestriction': basetype,
                            'baseType': 'FIELDNAME',
                            'showAllFieldsOption': true
                        };

                        thisWidget.properties['MashupParameters'].push(
                                {
                                    ParameterName: name,
                                    Description: description,
                                    BaseType: basetype,
                                    DefaultValue: defaultValue
                                }
                        );

                    }
                }

                // Per MASHUP-3223, this is pretty dangerous to do ...
                //  Also, it shouldn't be done only if the mashup has parameters (although it doesn't actually make sense otherwise, does it?)

                if (isManuallyBeingSetNow === true) {
                    try {
                        var mashupDef = JSON.parse(data.mashupContent, TW.dateReviver);

                        thisWidget.properties['TooltipMashupWidth'] = mashupDef.UI.Properties.Width;
                        thisWidget.properties['TooltipMashupHeight'] = mashupDef.UI.Properties.Height;

                    }
                    catch (err) {
                        TW.log.error('An error occurred in TW.IDE.Widgets.repeater.loadMashupParameters()', err);
                    }
                }

                try {
                    switch (data.aspects.mashupType) {
                        case 'thingtemplatemashup':
                        case 'thingshapemashup':
                            if (allWidgetProps.properties['Entity'] === undefined) {
                                allWidgetProps.properties['Entity'] = {
                                    'baseType': 'THINGNAME',
                                    'defaultValue': undefined,
                                    //'isBaseProperty': false,
                                    'isVisible': true,
                                    'name': 'Entity',
                                    'type': "property",
                                    'isBindingTarget': true,
                                    'isBindingSource': true
                                };
                                thisWidget.properties['MashupParameters'].push(
                                        {
                                            ParameterName: 'Entity',
                                            Description: 'Entity For Mashup',
                                            BaseType: 'THINGNAME',
                                            DefaultValue: undefined,
                                            ParmDef: {}
                                        }
                                );
                            }
                            break;
                    }
                } catch (err) {
                }
            }
        });
    };
}
;
