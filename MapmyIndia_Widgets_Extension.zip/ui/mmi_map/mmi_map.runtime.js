TW.Runtime.Widgets.mmi_map = function () {

    var internalPath = "../Common/extensions/MMI_Widgets_ExtensionPackage/ui/mmi_map/";

    function addDependency() {

//        $("body").append('<script type="text/javascript" src="' + internalPath + 'label.js"></script>');

        $("head").append('<link rel="stylesheet" href="' + internalPath + 'notification.css">');
        $("body").append('<script src="' + internalPath + 'notification.js"></script>');
        $("body").append('<script src="' + internalPath + 'pis.min.js"></script>');
        $("body").append('<script src="' + internalPath + 'Leaflet.Editable.js"></script>');

    }
    var thisWidget = this;
    this.runtimeProperties = function () {
        return {
            'supportsAutoResize': true,
            'needsDataLoadingAndError': true,
            'propertyAttributes': {
                'TooltipLabel1': {'isLocalizable': true},
                'TooltipLabel2': {'isLocalizable': true},
                'TooltipLabel3': {'isLocalizable': true},
                'TooltipLabel4': {'isLocalizable': true},
                'RegionTooltipLabel1': {'isLocalizable': true},
                'RegionTooltipLabel2': {'isLocalizable': true},
                'RegionTooltipLabel3': {'isLocalizable': true},
                'RegionTooltipLabel4': {'isLocalizable': true},
                'CircularRegionTooltipLabel1': {'isLocalizable': true},
                'CircularRegionTooltipLabel2': {'isLocalizable': true},
                'CircularRegionTooltipLabel3': {'isLocalizable': true},
                'CircularRegionTooltipLabel4': {'isLocalizable': true}
            }
        };
    };

    this.resize = function (width, height) {
        try {
            if (mmi_map) {
                mmi_map.invalidateSize();
            }
        } catch (err) {
        }
    };

    this.defaultMarker = undefined;
    this.plotMarker = function (lat, lng, imageIcon, label, html) {

        if (thisWidget.defaultMarker) {
            thisWidget.map.removeLayer(thisWidget.defaultMarker);
        }

        var myIcon = L.icon({
            iconUrl: imageIcon,
            iconRetinaUrl: imageIcon,
            iconSize: [35, 35],
            iconAnchor: [20, 10]
        });
        var marker = L.marker([lat, lng], {
            icon: myIcon,
            title: 'Location Marker'
        });
        marker.addTo(thisWidget.map);
        thisWidget.defaultMarker = marker;
        return marker;
    }

    var defaultZoom = 10;
	
	
	
    this.renderHtml = function () {
        addDependency();
        tooltipMashupWidth = thisWidget.getProperty('TooltipMashupWidth');
        tooltipMashupHeight = thisWidget.getProperty('TooltipMashupHeight');
        var mashupName = thisWidget.getProperty('TooltipMashupName');
        if (mashupName !== undefined && mashupName.length > 0) {
            isMashupTooltipConfigured = true;
        }

        return '<div class="widget-content widget-map-runtime mmi-widget-main-map"><span class="textsize-large"></span>' + /* */ + '</div>';
    };
	
	


    var mmi_map = undefined;
    this.afterRender = function () {
        //Default Marker Styles
        this.markerStyle = TW.getStyleFromStyleDefinition(this.getProperty('MarkerStyle'));
        this.selectionMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('SelectionMarkerStyle'));
        this.selectedMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('SelectedMarkerStyle'));
        this.startMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('StartMarkerStyle'));
        this.endMarkerStyle = TW.getStyleFromStyleDefinition(this.getProperty('EndMarkerStyle'));
        TW.Runtime.Widgets.mmi_map.editablePolygonVertexStyle = TW.getStyleFromStyleDefinition(this.getProperty('editablePolygonVertexStyle'));
        this.pathStyle = TW.getStyleFromStyleDefinition(this.getProperty('PathStyle'));
        this.plannedRouteStyle = TW.getStyleFromStyleDefinition(this.getProperty('PlannedRouteStyle'));
        this.routeStyle = TW.getStyleFromStyleDefinition(this.getProperty('RouteStyle'));
        this.regionStyle = TW.getStyleFromStyleDefinition(this.getProperty('RegionStyle'));
        this.selectedRegionStyle = TW.getStyleFromStyleDefinition(this.getProperty('SelectedRegionStyle'));
        this.circularRegionStyle = TW.getStyleFromStyleDefinition(this.getProperty('CircularRegionStyle'));
        this.selectedCircularRegionStyle = TW.getStyleFromStyleDefinition(this.getProperty('SelectedCircularRegionStyle'));

        this.notify_Success_Style = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Notify_Success_Style'));
        this.notify_Error_Style = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Notify_Error_Style'));
        this.notify_Normal_Style = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Notify_Normal_Style'));

        MMI_API_UTIL.appendStyle();

        if (MapmyIndia) {
            this.map = new MapmyIndia.Map(this.jqElementId, {
                center: [28.63275, 77.21947],
                zoomControl: true,
                hybrid: false,
                search: false,
                location: true,
                editable: true,
            }).setView([28.63275, 77.21947], 5);

            mmi_map = this.map;
            mmi_map.setMaxBounds([[40.0, 100.0], [5.8, 60.0]]);
        }
        
		registerMapClickEvent();

        if (thisWidget.getProperty('ShowMapTooltips')) {
            MarkerMgmt.init();
        }
		
		setTimeout(function(){mmi_map.invalidateSize();}, 500);  
    };


    this.serviceInvoked = function (serviceName) {


    };
	
	function registerMapClickEvent(){
		var notify_window = undefined;
        if (thisWidget.getProperty('EnableLocationSelection')) {
            var lastClickTime = 0;
            mmi_map.on("click", function (event) {
                var thisClickTime = (new Date).getTime();
                if (thisClickTime - lastClickTime < 500) {
                    var location = new Object();
                    location.units = "WGS84";
                    location.elevation = 0.0;
                    location.latitude = event.latlng.lat;
                    location.longitude = event.latlng.lng;
                    MARKER_UTIL.selectLocationOnMap(location);
                    thisWidget.setProperty('SelectedLocation', location);
                    thisWidget.jqElement.triggerHandler('Changed');

                }
                lastClickTime = thisClickTime;
            });
            mmi_map.doubleClickZoom.disable();
        }
	}
	

    this.updateProperty = function (updatePropertyInfo) {

        debugger;
        if (updatePropertyInfo.TargetProperty === "Data") {
            MARKER_UTIL.plotInputAndUpdates(updatePropertyInfo);
        } else if (updatePropertyInfo.TargetProperty === "RegionData") {
            REGION_UTIL.plotInputAndUpdates(updatePropertyInfo);
        } else if (updatePropertyInfo.TargetProperty === "CircularRegionData") {
            CIRCULAR_REGION_UTIL.plotInputAndUpdates(updatePropertyInfo);
        }

        if (updatePropertyInfo.TargetProperty === 'SelectedLocation') {
            var location = updatePropertyInfo.RawSinglePropertyValue;
            if (location != undefined && location.latitude != 0 && location.longitude != 0 && location.latitude != undefined && location.longitude != undefined) {
                MARKER_UTIL.selectLocationOnMap(location);
                thisWidget.setProperty('SelectedLocation', location);
            } else {
                if (MARKER_UTIL.currentSelectedLocationOnMap) {
                    mmi_map.removeLayer(MARKER_UTIL.currentSelectedLocationOnMap);
                }
                thisWidget.setProperty('SelectedLocation', undefined);
            }

            return;
        }

        if (updatePropertyInfo.TargetProperty === 'Zoom') {
            var zoom = parseInt(updatePropertyInfo.RawSinglePropertyValue);
            mmi_map.setZoom(zoom);
            return;
        }
		
		
        if (updatePropertyInfo.TargetProperty === 'ToolTip_data') {
            if (thisWidget.getProperty('ShowMapTooltips')) {
                MAP_UTIL.addTooltip(updatePropertyInfo);
            }

            return;
        }

        if (updatePropertyInfo.TargetProperty === 'RouteData') {
            ROUTE_UTIL.drawRoute(updatePropertyInfo);
        }
        if (updatePropertyInfo.TargetProperty === 'PlannedRouteData') {
            ROUTE_UTIL.drawPlannedRoute(updatePropertyInfo);
        }


        switch (updatePropertyInfo.TargetProperty) {
            case 'ShowPathBetweenMarkers':
            case 'ShowStartMarker':
            case 'ShowEndMarker':
            case 'ShowMarkers':
                thisWidget.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                MARKER_UTIL.plotInputAndUpdates(updatePropertyInfo);
                break;
            case 'ShowRoute':
                thisWidget.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                //redrawRoute.call(this);
                break;
            case 'ShowPlannedRoute':
                thisWidget.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                //redrawPlannedRoute.call(this);
                break;
            case 'ShowRegions':
                thisWidget.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                REGION_UTIL.plotInputAndUpdates(updatePropertyInfo);
                break;
            case 'ShowCircularRegions':
                thisWidget.setProperty(updatePropertyInfo.TargetProperty, updatePropertyInfo.RawSinglePropertyValue);
                CIRCULAR_REGION_UTIL.plotInputAndUpdates(updatePropertyInfo);
                break;
        }

        if (updatePropertyInfo.TargetProperty === 'Notify_data') {
            MAP_UTIL.alert(updatePropertyInfo);
        }

    };

    var MAP_UTIL = {
        tooltipMarker: [],
        validateCoordiante: function (lat, lng) {
            var flag = false;
            if (lat !== undefined && !isNaN(lat) && lat.toString().trim().length > 0
                    && parseFloat(lat) > -90 && parseFloat(lat) < 90) {

                if (lng !== undefined && !isNaN(lng) && lng.toString().trim().length > 0
                        && parseFloat(lng) > -180 && parseFloat(lng) < 180) {
                    flag = true;
                }
            }
            return flag;
        },
        addTooltip: function (updatePropertyInfo) {

            MAP_UTIL.clearTooltipMarker();
            var toolTipTextField = thisWidget.getProperty('ToolTip_Text_Field');
            var toolTipLocationField = thisWidget.getProperty('ToolTip_Location_Field');
            var toolTipImageField = thisWidget.getProperty('ToolTip_Image_Field');

            var dataRows = updatePropertyInfo.ActualDataRows;
            for (var r in dataRows) {
                var row_ = dataRows[r];

                var textToPrint = row_[toolTipTextField];
                var location = row_[toolTipLocationField];
                var image = row_[toolTipImageField];


                var myIcon = undefined;
                var marker = undefined;
                if (image === undefined || image === "") {
                    myIcon = new L.DivIcon({
                        className: 'mmi-div-icon',
                        html: textToPrint,
                        iconAnchor: [15, -5]
                    });
                    marker = MAP_UTIL.plotTooltipMarker(location.latitude, location.longitude, myIcon);
                } else {
                    myIcon = L.icon({
                        iconUrl: image,
                        iconRetinaUrl: image,
                        iconSize: [35, 35],
                        iconAnchor: [20, 10]
                    });
                    marker = MAP_UTIL.plotTooltipMarker(location.latitude, location.longitude, myIcon, textToPrint);
                }
                marker.addTo(mmi_map);
                MAP_UTIL.tooltipMarker.push(marker);
            }
        },
        clearTooltipMarker: function () {
            if (MAP_UTIL.tooltipMarker.length > 0) {
                var marker = MAP_UTIL.tooltipMarker.pop();
                mmi_map.removeLayer(marker);
                MAP_UTIL.clearTooltipMarker();
            }
        },
        plotTooltipMarker: function (lat, lng, icon, label, html) {

            var marker = L.marker([lat, lng], {
                icon: icon
            });
            marker.addTo(mmi_map);
            if (label !== undefined) {
                marker.bindTooltip(label, {
                    permanent: false,
                    direction: 'right',
                    className: 'tooltip_image_css' //custom css class to style label
                });
            }
            if (html !== undefined) {
                marker.bindPopup(html);
            }
            return marker;
        },
        alert: function (updatePropertyInfo) {

            var notifyLayout = thisWidget.getProperty('Notify_Layout');
            var notifyTimeout = thisWidget.getProperty('Notify_Timeout');
            if (notifyTimeout < 1) {
                notifyTimeout = false;
            }
            var notifyTypeField = thisWidget.getProperty('Notify_Type_Field');
            var notifyTextField = thisWidget.getProperty('Notify_Text_Field');



            var dataRows = updatePropertyInfo.ActualDataRows;
            for (var r in dataRows) {
                var row_ = dataRows[r];
                var notifyType = row_[notifyTypeField];
                var notifyText = row_[notifyTextField];
                if (notifyText && notifyType) {
                    var n = new Noty({
                        type: notifyType,
                        text: notifyText,
                        layout: notifyLayout,
                        theme: "mmi_custom",
                        progressBar: false,
                        timeout: notifyTimeout,
                        closeWith: ['click', 'button']
                    }).show();

                }
            }

        },
    }


    MarkerMgmt = {
        maxMarkerOnScreen: thisWidget.getProperty('MaxTooltipsInVisibleArea'),
        init: function () {
            mmi_map.on('moveend', function (e) {
                MarkerMgmt.showMarker();
            });
        },
        hideAllMarker: function () {
            for (var m = 0; m < MAP_UTIL.tooltipMarker.length; m++) {
                var marker = MAP_UTIL.tooltipMarker[m];
                if (mmi_map.hasLayer(marker)) {
                    mmi_map.removeLayer(marker);
                }
            }
        },
        showMarker: function () {
            MarkerMgmt.hideAllMarker();
            var arr = MarkerMgmt.markerInBound();
            var totalMarker = arr.length;
            if (totalMarker > MarkerMgmt.maxMarkerOnScreen) {
                var skipCount = parseInt(totalMarker / MarkerMgmt.maxMarkerOnScreen);
                if (skipCount === 0) {
                    skipCount = 1;
                }
                MarkerMgmt.showPartialMarker(skipCount, arr);
            } else {
                MarkerMgmt.showPartialMarker(1, arr);
            }
        },
        showPartialMarker: function (skipCount, arr) {
            var count = parseInt(skipCount);
            for (var m = 0; m < arr.length; m += count) {
                arr[m].addTo(mmi_map);
            }
        },
        markerInBound: function () {

            var size__ = MAP_UTIL.tooltipMarker.length;
            var arr__ = [];
            for (var m = 0; m < size__; m++) {
                if (mmi_map.getBounds().contains(MAP_UTIL.tooltipMarker[m].getLatLng())) {
                    arr__.push(MAP_UTIL.tooltipMarker[m]);
                }
            }
            return arr__;
        }
    }



    this.beforeDestroy = function () {

    };

    // Tooltip Mashup Setup
    var regionInfoWindow = undefined;
    var lastRegionNumber = undefined;
    var lastData = undefined;
    var lastRegionData = undefined;
    var infoId = 'MapInfoWindow' + TW.uniqueId();
    var tooltipMashupWidth = 100;
    var tooltipMashupHeight = 100;
    var isMashupTooltipConfigured = false;
    var isRegionTooltipConfigured = false;
    var dataInfotable = undefined;

    var MARKER_UTIL = {
        selectedMarkerIndexArr: [],
        plottedmarkerList: [],
        currentSelectedLocationOnMap: undefined,
        selectLocationOnMap: function (newLocation) {

            if (newLocation !== undefined) {
                if (thisWidget.getProperty('ShowSelectionMarker') === true) {
                    if (MARKER_UTIL.currentSelectedLocationOnMap) {
                        mmi_map.removeLayer(MARKER_UTIL.currentSelectedLocationOnMap);
                    }
                    var marker_prop = new Object();
                    marker_prop.latitude = newLocation.latitude;
                    marker_prop.longitude = newLocation.longitude;
                    marker_prop.imageIcon = thisWidget.selectionMarkerStyle.image;
                    marker_prop.label = undefined;
                    marker_prop.html = undefined;
                    marker_prop.title = "Selection";
                    MARKER_UTIL.currentSelectedLocationOnMap = MARKER_UTIL.plotMarker(marker_prop);


                }
                mmi_map.setView([newLocation.latitude, newLocation.longitude], mmi_map.getZoom());
            }

        },
        plotMarker: function (marker_prop) {


            if (marker_prop.draggable === undefined) {
                marker_prop.draggable = false;
            }

            var myIcon = L.icon({
                iconUrl: marker_prop.imageIcon,
                iconRetinaUrl: marker_prop.imageIcon,
                iconSize: [35, 35],
                iconAnchor: [20, 10]
            });
            var title = "";
            if (marker_prop.title) {
                title = marker_prop.title;
            }

            var marker = L.marker([marker_prop.latitude, marker_prop.longitude], {
                icon: myIcon,
                title: title,
                draggable: marker_prop.draggable
            });

            marker.addTo(mmi_map);
            marker.data = marker_prop.data;
            marker.rowNumber = marker_prop.rowNumber;
            marker._isSelected = marker_prop._isSelected;

            if (marker_prop.label != undefined) {

                marker.bindTooltip(marker_prop.label, {
                    permanent: false,
                    direction: 'right',
                    className: 'myCSSClass' //custom css class to style label
                });


            }
            if (marker_prop.html != undefined) {
                marker.bindPopup(marker_prop.html);
            }
            return marker;
        },
        plotInputAndUpdates: function (updatePropertyInfo) {
            MARKER_UTIL.clearPlottedMarker();

            var dataRows = updatePropertyInfo.ActualDataRows;
            var showMarkers = thisWidget.getProperty('ShowMarkers');
            var locationField = thisWidget.getProperty('LocationField');
            var showMarkerTooltips = thisWidget.getProperty('ShowMarkerTooltips');
            var enableMarkerSelection = thisWidget.getProperty('EnableMarkerSelection');
            if (showMarkerTooltips == null || showMarkerTooltips == undefined) {
                showMarkerTooltips = true;
            }

            var isMultiselect = thisWidget.properties['MultiSelect'];
            var selectedRowIndices = updatePropertyInfo.SelectedRowIndices;
            // Getting Marker Style
            for (var r in dataRows) {
                if (showMarkers) {
                    var row = dataRows[r];
                    var thisLocation = row[locationField];
                    if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {

                       
                        var markerIcon = MARKER_UTIL.getMarkerImage(row);
                        var isSelected = false;
                        if (isMultiselect && selectedRowIndices !== undefined) {
                            if (selectedRowIndices.indexOf(r) !== -1) {
                                isSelected = true;
                                if (thisWidget.selectedMarkerStyle !== undefined) {
                                    markerIcon = thisWidget.selectedMarkerStyle.image;
                                }
                            }
                        }


                        var marker_prop = new Object();
                        marker_prop.latitude = thisLocation.latitude;
                        marker_prop.longitude = thisLocation.longitude;
                        marker_prop.imageIcon = markerIcon;
                        marker_prop.label = undefined;
                        marker_prop.html = undefined;
                        marker_prop.data = row;
                        marker_prop.rowNumber = r;
                        marker_prop._isSelected = isSelected;

                        var title = undefined;
                        if (showMarkerTooltips) {
                            marker_prop.title = MARKER_UTIL.getMarkerTooltipTitle(row);
                        }

                        var marker = MARKER_UTIL.plotMarker(marker_prop);
                        MARKER_UTIL.plottedmarkerList.push(marker);
                        if (enableMarkerSelection) {
                            marker.on("click", function (marker_) {
                                MARKER_UTIL.setSelectedMarker(marker_.target.rowNumber);
                            });
                        }
                        if (showMarkerTooltips) {
                            marker.on("mouseover ", function (marker_) {
                                MARKER_UTIL.openInfoWindowOnMouseOver(marker_);
                            });
                        }
                    }
                }
            }
            if (showMarkers) {
                MARKER_UTIL.setBoundToPlottedMarker();
            }
            var showPathBetweenMarkers = thisWidget.getProperty('ShowPathBetweenMarkers');
            if (showPathBetweenMarkers) {
                MARKER_UTIL.connectMarkers();
            }
            MARKER_UTIL.clearSelectedMarkers();
        },
        getMarkerTooltipTitle: function (row) {

            var tooltipField1 = thisWidget.getProperty('TooltipField1');
            var tooltipLabel1 = thisWidget.getProperty('TooltipLabel1');
            var tooltipField2 = thisWidget.getProperty('TooltipField2');
            var tooltipLabel2 = thisWidget.getProperty('TooltipLabel2');
            var tooltipField3 = thisWidget.getProperty('TooltipField3');
            var tooltipLabel3 = thisWidget.getProperty('TooltipLabel3');
            var tooltipField4 = thisWidget.getProperty('TooltipField4');
            var tooltipLabel4 = thisWidget.getProperty('TooltipLabel4');

            var title = '';

            if (tooltipField1 !== undefined && tooltipField1 !== '') {
                if (tooltipLabel1 !== undefined && tooltipLabel1 !== '')
                    title = title + tooltipLabel1 + ' : ';
                else
                    title = title + tooltipField1 + ' : ';

                title = title + row[tooltipField1];
            }

            if (tooltipField2 !== undefined && tooltipField2 !== '') {
                if (title.length > 0)
                    title = title + '\n';

                if (tooltipLabel2 !== undefined && tooltipLabel2 !== '')
                    title = title + tooltipLabel2 + ' : ';
                else
                    title = title + tooltipField2 + ' : ';

                title = title + row[tooltipField2];
            }

            if (tooltipField3 !== undefined && tooltipField3 !== '') {
                if (title.length > 0)
                    title = title + '\n';

                if (tooltipLabel3 !== undefined && tooltipLabel3 !== '')
                    title = title + tooltipLabel3 + ' : ';
                else
                    title = title + tooltipField3 + ' : ';

                title = title + row[tooltipField3];
            }

            if (tooltipField4 !== undefined && tooltipField4 !== '') {
                if (title.length > 0)
                    title = title + '\n';

                if (tooltipLabel4 !== undefined && tooltipLabel4 !== '')
                    title = title + tooltipLabel4 + ' : ';
                else
                    title = title + tooltipField4 + ' : ';

                title = title + row[tooltipField4];
            }
            return title;

        },
        getMarkerImage: function (row) {
            var markerIcon = "";
            var markerField = thisWidget.properties['MarkerField'];
            var hasFormatting = thisWidget.properties['MarkerFormatting'] !== undefined;
            if (hasFormatting) {
                var formatStyle = TW.getStyleFromStateFormatting({DataRow: row, StateFormatting: thisWidget.properties['MarkerFormatting']});
                if (formatStyle.styleDefinitionName !== undefined) {
                    markerIcon = formatStyle.image;
                } else {
                    markerIcon = thisWidget.markerStyle.image;
                }
            } else {
                markerIcon = thisWidget.markerStyle.image;
            }

            if (markerField !== undefined && markerField !== '') {
                var markerImagePath = row[markerField];
                if (markerImagePath !== undefined && markerImagePath !== '') {
                    markerIcon = markerImagePath;
                }
            }
            return markerIcon;
        },
        setSelectedMarker: function (indexOfMarker) {

            var isMultiselect = thisWidget.properties['MultiSelect'];
            var marker = MARKER_UTIL.plottedmarkerList[indexOfMarker];
            var marker_selected = marker._isSelected;
            if (!isMultiselect) {
                if (marker_selected || MARKER_UTIL.selectedMarkerIndexArr.length > 0) {
                    MARKER_UTIL.clearSelectedMarkers();
                }
            }



            if (marker_selected) {
                var markerIcon = MARKER_UTIL.getMarkerImage(marker.data);
                var myIcon = L.icon({
                    iconUrl: markerIcon,
                    iconRetinaUrl: markerIcon,
                    iconSize: [35, 35],
                    iconAnchor: [20, 10]
                });
                marker._isSelected = false;
                marker.setIcon(myIcon);
            } else {
                if (thisWidget.selectedMarkerStyle !== undefined) {

                    var myIcon = L.icon({
                        iconUrl: thisWidget.selectedMarkerStyle.image,
                        iconRetinaUrl: thisWidget.selectedMarkerStyle.image,
                        iconSize: [35, 35],
                        iconAnchor: [20, 10]
                    });
                    marker._isSelected = true;
                    marker.setIcon(myIcon);
                    MARKER_UTIL.selectedMarkerIndexArr.push(marker.rowNumber);
                }
            }


        },
        clearSelectedMarkers: function () {

            MARKER_UTIL.selectedMarkerIndexArr = [];
            for (var m in MARKER_UTIL.plottedmarkerList) {
                var currentMarker = MARKER_UTIL.plottedmarkerList[m];
                var markerIcon = MARKER_UTIL.getMarkerImage(currentMarker.data);
                var myIcon = L.icon({
                    iconUrl: markerIcon,
                    iconRetinaUrl: markerIcon,
                    iconSize: [35, 35],
                    iconAnchor: [20, 10]
                });
                currentMarker._isSelected = false;
                currentMarker.setIcon(myIcon);
            }
        },
        setBoundToPlottedMarker: function () {
            var latlngArr = [];
            for (var m in MARKER_UTIL.plottedmarkerList) {
                latlngArr.push(MARKER_UTIL.plottedmarkerList[m].getLatLng());
            }
            mmi_map.fitBounds(L.latLngBounds(latlngArr));
        },
        clearPlottedMarker: function () {
            if (MARKER_UTIL.plottedmarkerList.length > 0) {
                var marker = MARKER_UTIL.plottedmarkerList.pop();
                mmi_map.removeLayer(marker);
                MARKER_UTIL.clearPlottedMarker();
            }
        },
        cleanupTooltipMashup: function () {
            try {
                var mashupTooltips = $('#' + infoId);
                if (mashupTooltips.length > 0) {
                    mashupTooltips.mashup('destroy');
                    TW.purgeJqElement(mashupTooltips);
                }
            }
            catch (destroyErr) {

            }
        },
        openInfoWindowOnMouseOver: function (marker_) {

            if (!isMashupTooltipConfigured) {
                return;
            }




            var selectedRowNo = marker_.target.rowNumber;
            var marker = MARKER_UTIL.plottedmarkerList[selectedRowNo];

            TW.log.info('Should display info for Row #' + selectedRowNo);
            //thisWidget.setSelectedMarker(selectedRowNo);

            MARKER_UTIL.cleanupTooltipMashup();

            var popup = L.popup({minWidth: tooltipMashupWidth});
            popup.setLatLng(marker.getLatLng());
            popup.setContent('<div id="' + infoId + '" style="width:' + tooltipMashupWidth + 'px;height:' + tooltipMashupHeight + 'px;">Loading Tooltip Mashup...</div>');
            popup.openOn(mmi_map);

            setTimeout(function () {
                var mashupSpec = {};
                mashupSpec.mashupName = thisWidget.getProperty('TooltipMashupName');
                mashupSpec.mashupParameters = {};

                var mashupParameters = thisWidget.properties['MashupParameters'];
                if (mashupParameters === undefined)
                    mashupParameters = [];

                var nParams = mashupParameters.length;

                for (var paramNo = 0; paramNo < nParams; paramNo++) {
                    var paramInfo = mashupParameters[paramNo],
                            propName = paramInfo.ParameterName,
                            fldName = thisWidget.getProperty(propName),
                            propValue;
                    if (fldName === 'ALL_FIELDS') {
                        propValue = JSON.parse(JSON.stringify(dataInfotable));
                        propValue.rows.push(lastData[selectedRowNo]);
                    } else {
                        propValue = lastData[selectedRowNo][thisWidget.getProperty(propName)];
                    }
                    if (propValue !== undefined) {
                        mashupSpec.mashupParameters[propName] = propValue;
                    }
                }

                $('#' + infoId).mashup(mashupSpec);
            }, 100);
            return;


        },
        pathShown: undefined,
        pathStartMarker: undefined,
        pathEndMarker: undefined,
        connectMarkers: function () {
            var showPathBetweenMarkers = thisWidget.getProperty('ShowPathBetweenMarkers');
            if (MARKER_UTIL.plottedmarkerList.length > 1 && showPathBetweenMarkers) {

                var startMarker = MARKER_UTIL.plottedmarkerList[0];
                var endMarker = undefined;
                var latlngArr = [];
                for (var m in MARKER_UTIL.plottedmarkerList) {
                    var marker = MARKER_UTIL.plottedmarkerList[m];
                    latlngArr.push(marker.getLatLng());
                    endMarker = marker;
                }

                if (MARKER_UTIL.pathShown) {
                    mmi_map.removeLayer(MARKER_UTIL.pathShown);
                }
                MARKER_UTIL.pathShown = new L.Polyline(latlngArr, {
                    color: thisWidget.pathStyle.lineColor,
                    weight: parseInt(thisWidget.pathStyle.lineThickness),
                    opacity: 1,
                    smoothFactor: 1
                });
                MARKER_UTIL.pathShown.addTo(mmi_map);


                if (thisWidget.getProperty('ShowEndMarker')) {
                    var marker_prop = new Object();
                    marker_prop.latitude = endMarker.getLatLng().lat;
                    marker_prop.longitude = endMarker.getLatLng().lng;
                    marker_prop.imageIcon = thisWidget.endMarkerStyle.image;
                    marker_prop.label = "End";
                    marker_prop.html = undefined;
                    marker_prop.title = "Selection";
                    MARKER_UTIL.pathEndMarker = MARKER_UTIL.plotMarker(marker_prop);
                }

                if (thisWidget.getProperty('ShowStartMarker')) {
                    var marker_prop = new Object();
                    marker_prop.latitude = startMarker.getLatLng().lat;
                    marker_prop.longitude = startMarker.getLatLng().lng;
                    marker_prop.imageIcon = thisWidget.startMarkerStyle.image;
                    marker_prop.label = "Start";
                    marker_prop.html = undefined;
                    marker_prop.title = "Selection";
                    MARKER_UTIL.pathStartMarker = MARKER_UTIL.plotMarker(marker_prop);
                }

            }
        }


    }

    var REGION_UTIL = {
        plottedRegions: [],
        plottedRegionsCenterMarker: [],
        registerEdit: function (polygon) {
            polygon.on("editable:vertex:dragend", function (e) {
                var poly_ = this;
                var uniqueKey = poly_.uniqueKey;
                var latlngArr = poly_.getLatLngs()[0];


                var dataRows = REGION_UTIL.updatePropertyInfo.ActualDataRows;
                for (var dr in dataRows) {
                    var row = dataRows[dr];
                    if (uniqueKey == row.uniqueKey) {
                        var locationsField = thisWidget.getProperty('RegionLocationsField');
                        var locationField = thisWidget.getProperty('RegionLocationField');
                        var locationTable = row[locationsField];
                        var regionDataRowsNew = [];
                        for (var l in latlngArr) {
                            var latlng = latlngArr[l];
                            var location = new Object();
                            location.latitude = latlng.lat;
                            location.longitude = latlng.lng;
                            location.elevation = 0;
                            location.units = "WGS84";
                            var obj = new Object();
                            obj.locationSequence = (+l + 1);
                            obj[locationField] = location;
                            regionDataRowsNew.push(obj);
                        }
                        locationTable.rows = regionDataRowsNew;

                        break;
                    }

                }

                //thisWidget.updateProperty(REGION_UTIL.updatePropertyInfo);
                //thisWidget.setProperty("RegionData", REGION_UTIL.updatePropertyInfo);

            });
            
//            polygon.on("editable:vertex:click", function (e) {
//                debugger;
//                var url = location.origin + "/Thingworx/Things/" + MMI_API_UTIL.autosuggestThingName + "/Services/"
//                        + MMI_API_UTIL.reverseGeocodeServiceName + "?lat=" + e.latlng.lat + "&lng=" + e.latlng.lng;
//                $.ajax({
//                    url: url,
//                    type: 'post',
//                    data: {},
//                    headers: {
//                        'Content-Type': 'application/json'
//                    },
//                    dataType: 'json',
//                    success: function (d) {
//                        if (d.responseCode == 200) {
//
//                            var html = '<table ><tbody>'
//                                    + '<tr><td><b>Address: </b></td><td>' + d.results[0].formatted_address + '</td><td></td></tr>'
//                                    + '<tr><td><b>Lat: </b></td><td>' + e.latlng.lat + '</td><td></td></tr>'
//                                    + '<tr><td><b>Lng: </b></td><td>' + e.latlng.lng + '</td><td></td></tr></tbody></table>';
//                            MMI_API_UTIL.reverseGeocodePopup = L.popup()
//                                    .setLatLng(e.latlng)
//                                    .setContent(html)
//                                    .openOn(thisWidget.map);
//                        }
//                    }
//                });
//            });
            
            
        },
        registerCenterEdit: function (marker) {
            marker.on("dragend", function (e) {

                var marker = e.target;
                var position = marker.getLatLng();
                var uniqueKey = marker.data.uniqueKey;

                var dataRows = REGION_UTIL.updatePropertyInfo.ActualDataRows;
                for (var dr in dataRows) {
                    var row = dataRows[dr];
                    if (uniqueKey == row.uniqueKey) {
                        var centerOfPolygonField = thisWidget.getProperty('CenterOfPolygon');
                        var obj = new Object();
                        obj.latitude = position.lat;
                        obj.longitude = position.lng;
                        row[centerOfPolygonField] = obj;

                        break;
                    }

                }

               
            });
        },
        updatePropertyInfo: undefined,
        plotInputAndUpdates: function (updatePropertyInfo) {

            REGION_UTIL.updatePropertyInfo = updatePropertyInfo;
            debugger;
            var showRegions = thisWidget.getProperty('ShowRegions');
            var showRegionTooltips = thisWidget.getProperty('ShowRegionTooltips');
            REGION_UTIL.clearPlottedRegion();
            REGION_UTIL.clearplottedRegionsCenterMarker();

            if (showRegions) {

                var dataRows = updatePropertyInfo.ActualDataRows;
                var enableRegionSelection = thisWidget.getProperty('EnableRegionSelection');
                var locationField = thisWidget.getProperty('RegionLocationField');
                var locationsField = thisWidget.getProperty('RegionLocationsField');
                var fillOpacity = thisWidget.getProperty('RegionFillOpacity');
                var centerOfPolygonField = thisWidget.getProperty('CenterOfPolygon');
                var isPolygonEditable = thisWidget.getProperty('isPolygonEditable');
                var centerOfPolygonStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('CenterOfPolygonStyle'));


                for (var dr in dataRows) {
                    var row = dataRows[dr];
                    row.uniqueKey = "poly-" + dr;
                    var locationTable = row[locationsField];
                    var centerLocation = row[centerOfPolygonField];
                    if (locationTable !== undefined) {

                        var regionDataRows = locationTable.rows;
                        var latlngArr = [];
                        for (var rdr in regionDataRows) {
                            var regionRow = regionDataRows[rdr];
                            var thisLocation = regionRow[locationField];
                            if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {
                                latlngArr.push([thisLocation.latitude, thisLocation.longitude]);
                            }
                        }
                        if (latlngArr.length > 0) {

                            var hasRegionFormatting = thisWidget.properties['RegionFormatting'] !== undefined;
                            var formatStyle = thisWidget.regionStyle;
                            if (hasRegionFormatting) {
                                formatStyle = TW.getStyleFromStateFormatting({DataRow: row, StateFormatting: thisWidget.properties['RegionFormatting']});
                            }


                            var polygon = L.polygon(latlngArr, {
                                "color": formatStyle.lineColor,
                                "fillColor": formatStyle.backgroundColor,
                                "weight": parseInt(formatStyle.lineThickness),
                                "fillOpacity": fillOpacity
                            });
                            polygon.uniqueKey = row.uniqueKey;
                            polygon.data = row;
                            polygon.rowNumber = dr;
                            polygon.addTo(mmi_map);
                            if (isPolygonEditable) {
                                polygon.enableEdit();
                                REGION_UTIL.registerEdit(polygon);
                            }

                            REGION_UTIL.plottedRegions.push(polygon);

                            var title = "";
                            if (showRegionTooltips) {
                                title = REGION_UTIL.getRegionTooltip(row);
                                polygon.bindTooltip(title);
                            }

                            if (enableRegionSelection) {
                                polygon.on("click", function (polygon_) {
                                    REGION_UTIL.setSelectedRegion(polygon_.target.rowNumber);
                                });
                            }

                            // Add Cenrtre of Polygon


                            if (centerLocation !== undefined && MAP_UTIL.validateCoordiante(centerLocation.latitude, centerLocation.longitude)) {
                                var marker_prop = new Object();
                                marker_prop.latitude = centerLocation.latitude;
                                marker_prop.longitude = centerLocation.longitude;
                                marker_prop.imageIcon = centerOfPolygonStyle.image;
                                marker_prop.label = undefined;
                                marker_prop.html = undefined;
                                marker_prop.title = undefined;
                                marker_prop.draggable = isPolygonEditable;
                                var data = new Object();
                                data.uniqueKey = row.uniqueKey;
                                marker_prop.data = data;
                                var centrMrkr = MARKER_UTIL.plotMarker(marker_prop);
                                REGION_UTIL.plottedRegionsCenterMarker.push(centrMrkr);
                                if (isPolygonEditable) {
                                    REGION_UTIL.registerCenterEdit(centrMrkr);
                                }
                            }
                        }

                    }
                }

                if (REGION_UTIL.plottedRegions.length > 1) {
                    REGION_UTIL.setBoundToPlottedRegion();
                } else if (REGION_UTIL.plottedRegions.length > 0) {
                    mmi_map.fitBounds(REGION_UTIL.plottedRegions[0].getBounds());
                }

            }
        },
        getRegionTooltip: function (row) {

            var tooltipField1 = thisWidget.getProperty('RegionTooltipField1');
            var tooltipLabel1 = thisWidget.getProperty('RegionTooltipLabel1');
            var tooltipField2 = thisWidget.getProperty('RegionTooltipField2');
            var tooltipLabel2 = thisWidget.getProperty('RegionTooltipLabel2');
            var tooltipField3 = thisWidget.getProperty('RegionTooltipField3');
            var tooltipLabel3 = thisWidget.getProperty('RegionTooltipLabel3');
            var tooltipField4 = thisWidget.getProperty('RegionTooltipField4');
            var tooltipLabel4 = thisWidget.getProperty('RegionTooltipLabel4');


            var title = '';

            if (tooltipField1 !== undefined && tooltipField1 !== '') {
                if (tooltipLabel1 !== undefined && tooltipLabel1 !== '')
                    title = title + tooltipLabel1 + ' : ';
                else
                    title = title + tooltipField1 + ' : ';

                title = title + row[tooltipField1];
            }

            if (tooltipField2 !== undefined && tooltipField2 !== '') {
                if (title.length > 0)
                    title = title + '<BR>';

                if (tooltipLabel2 !== undefined && tooltipLabel2 !== '')
                    title = title + tooltipLabel2 + ' : ';
                else
                    title = title + tooltipField2 + ' : ';

                title = title + row[tooltipField2];
            }

            if (tooltipField3 !== undefined && tooltipField3 !== '') {
                if (title.length > 0)
                    title = title + '<BR>';

                if (tooltipLabel3 !== undefined && tooltipLabel3 !== '')
                    title = title + tooltipLabel3 + ' : ';
                else
                    title = title + tooltipField3 + ' : ';

                title = title + row[tooltipField3];
            }

            if (tooltipField4 !== undefined && tooltipField4 !== '') {
                if (title.length > 0)
                    title = title + '<BR>';

                if (tooltipLabel4 !== undefined && tooltipLabel4 !== '')
                    title = title + tooltipLabel4 + ' : ';
                else
                    title = title + tooltipField4 + ' : ';

                title = title + row[tooltipField4];
            }
            return title;

        },
        clearPlottedRegion: function () {
            if (REGION_UTIL.plottedRegions.length > 0) {
                var polygon = REGION_UTIL.plottedRegions.pop();
                mmi_map.removeLayer(polygon);
                REGION_UTIL.clearPlottedRegion();
            }
        },
        clearplottedRegionsCenterMarker: function () {
            if (REGION_UTIL.plottedRegionsCenterMarker.length > 0) {
                var polygon = REGION_UTIL.plottedRegionsCenterMarker.pop();
                mmi_map.removeLayer(polygon);
                REGION_UTIL.clearplottedRegionsCenterMarker();
            }
        },
        setBoundToPlottedRegion: function () {
            var latlngArr = [];
            for (var m in REGION_UTIL.plottedRegions) {
                latlngArr.push(REGION_UTIL.plottedRegions[m].getBounds().getCenter());
            }
            mmi_map.fitBounds(L.latLngBounds(latlngArr));
        },
        selectedRegionRows: [],
        setSelectedRegion: function (rowIndex) {

            var isMultiselect = thisWidget.properties['RegionMultiSelect'];
            var selectedPolygon = REGION_UTIL.plottedRegions[rowIndex];

            var hasRegionFormatting = thisWidget.properties['RegionFormatting'] !== undefined;
            var formatStyle = thisWidget.regionStyle;
            if (hasRegionFormatting) {
                formatStyle = TW.getStyleFromStateFormatting({DataRow: selectedPolygon.target.data, StateFormatting: thisWidget.properties['RegionFormatting']});
            }
            var fillOpacity = thisWidget.getProperty('RegionFillOpacity');


            if (selectedPolygon !== undefined) {
                if (selectedPolygon._isSelected) {
                    if (isMultiselect) {
                        TW.removeElementFromArray(REGION_UTIL.selectedRegionRows, rowIndex);
                        selectedPolygon._isSelected = false;
                        selectedPolygon.setStyle(
                                {"color": formatStyle.lineColor,
                                    "fillColor": formatStyle.backgroundColor,
                                    "weight": parseInt(formatStyle.lineThickness),
                                    "fillOpacity": fillOpacity}
                        );
                        thisWidget.updateSelection('RegionData', REGION_UTIL.selectedRegionRows);
                    }
                } else {
                    if (!isMultiselect) {
                        REGION_UTIL.clearSelectedRegions();
                        REGION_UTIL.selectedRegionRows = [rowIndex];
                    }
                    else {
                        REGION_UTIL.selectedRegionRows.push(rowIndex);
                    }
                    selectedPolygon.setStyle(
                            {"color": thisWidget.selectedRegionStyle.lineColor,
                                "fillColor": thisWidget.selectedRegionStyle.backgroundColor,
                                "weight": parseInt(thisWidget.selectedRegionStyle.lineThickness),
                                "fillOpacity": fillOpacity}
                    );
                    selectedPolygon._isSelected = true;
                    thisWidget.updateSelection('RegionData', REGION_UTIL.selectedRegionRows);

                }
            }
        },
        clearSelectedRegions: function () {
            REGION_UTIL.selectedRegionRows = [];
            for (var r in REGION_UTIL.plottedRegions) {
                var polygon = REGION_UTIL.plottedRegions[r];
                var fillOpacity = thisWidget.getProperty('RegionFillOpacity');
                var hasRegionFormatting = thisWidget.properties['RegionFormatting'] !== undefined;
                var formatStyle = thisWidget.regionStyle;
                if (hasRegionFormatting) {
                    formatStyle = TW.getStyleFromStateFormatting({DataRow: polygon.target.data, StateFormatting: thisWidget.properties['RegionFormatting']});
                }
                polygon.setStyle(
                        {"color": formatStyle.lineColor,
                            "fillColor": formatStyle.backgroundColor,
                            "weight": parseInt(formatStyle.lineThickness),
                            "fillOpacity": fillOpacity}
                );
                polygon._isSelected = false;
            }
        }
    }

    var CIRCULAR_REGION_UTIL = {
        plottedCircularRegions: [],
        plottedCircularCenter: [],
        plotInputAndUpdates: function (updatePropertyInfo) {
            var showRegions = thisWidget.getProperty('ShowCircularRegions');
            var showCircularRegionTooltips = thisWidget.getProperty('ShowCircularRegionTooltips');
            var centerOfCircleStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('CenterOfCircleStyle'));
            CIRCULAR_REGION_UTIL.clearPlottedCircularRegion();
            CIRCULAR_REGION_UTIL.clearPlottedCircularCenter();

            if (showRegions) {

                var dataRows = updatePropertyInfo.ActualDataRows;
                var enableRegionSelection = thisWidget.getProperty('EnableCircularRegionSelection');
                var locationField = thisWidget.getProperty('CircularRegionLocationField');
                var radiusField = thisWidget.getProperty('CircleRadiusField');
                var fillOpacity = thisWidget.getProperty('CircularRegionFillOpacity');


                for (var dr in dataRows) {
                    var row = dataRows[dr];
                    var location = row[locationField];
                    var radius = row[radiusField];
                    if (location !== undefined && radius !== undefined) {

                        var hasRegionFormatting = thisWidget.properties['CircularRegionFormatting'] !== undefined;
                        var formatStyle = thisWidget.circularRegionStyle;
                        if (hasRegionFormatting) {
                            formatStyle = TW.getStyleFromStateFormatting({DataRow: row, StateFormatting: thisWidget.properties['CircularRegionFormatting']});
                        }


                        var circle = L.circle([location.latitude, location.longitude], {
                            radius: radius,
                            "color": formatStyle.lineColor,
                            "fillColor": formatStyle.backgroundColor,
                            "weight": parseInt(formatStyle.lineThickness),
                            "fillOpacity": fillOpacity
                        });
                        circle.data = row;
                        circle.rowNumber = dr;
                        circle.addTo(mmi_map);
                        CIRCULAR_REGION_UTIL.plottedCircularRegions.push(circle);

                        var title = "";
                        if (showCircularRegionTooltips) {
                            title = CIRCULAR_REGION_UTIL.getRegionTooltip(row);
                            circle.bindTooltip(title);
                        }

                        if (enableRegionSelection) {
                            circle.on("click", function (circle_) {
                                CIRCULAR_REGION_UTIL.setSelectedRegion(circle_.target.rowNumber);
                            });
                        }

                    
                        if (MAP_UTIL.validateCoordiante(location.latitude, location.longitude)) {
                            var marker_prop = new Object();
                            marker_prop.latitude = location.latitude;
                            marker_prop.longitude = location.longitude;
                            marker_prop.imageIcon = centerOfCircleStyle.image;
                            marker_prop.label = undefined;
                            marker_prop.html = undefined;
                            marker_prop.title = undefined;
                            CIRCULAR_REGION_UTIL.plottedCircularCenter.push(MARKER_UTIL.plotMarker(marker_prop));
                        }

                    }
                }
                if (CIRCULAR_REGION_UTIL.plottedCircularRegions.length > 1) {
                    CIRCULAR_REGION_UTIL.setBoundToPlottedCircularRegion();
                } else if (CIRCULAR_REGION_UTIL.plottedCircularRegions.length > 0) {
                    mmi_map.fitBounds(CIRCULAR_REGION_UTIL.plottedCircularRegions[0].getBounds());
                }

            }
        },
        getRegionTooltip: function (row) {

            var tooltipField1 = thisWidget.getProperty('CircularRegionTooltipField1');
            var tooltipLabel1 = thisWidget.getProperty('CircularRegionTooltipLabel1');
            var tooltipField2 = thisWidget.getProperty('CircularRegionTooltipField2');
            var tooltipLabel2 = thisWidget.getProperty('CircularRegionTooltipLabel2');
            var tooltipField3 = thisWidget.getProperty('CircularRegionTooltipField3');
            var tooltipLabel3 = thisWidget.getProperty('CircularRegionTooltipLabel3');
            var tooltipField4 = thisWidget.getProperty('CircularRegionTooltipField4');
            var tooltipLabel4 = thisWidget.getProperty('CircularRegionTooltipLabel4');

            var title = '';

            if (tooltipField1 !== undefined && tooltipField1 !== '') {
                if (tooltipLabel1 !== undefined && tooltipLabel1 !== '')
                    title = title + tooltipLabel1 + ' : ';
                else
                    title = title + tooltipField1 + ' : ';

                title = title + row[tooltipField1];
            }

            if (tooltipField2 !== undefined && tooltipField2 !== '') {
                if (title.length > 0)
                    title = title + '<BR>';

                if (tooltipLabel2 !== undefined && tooltipLabel2 !== '')
                    title = title + tooltipLabel2 + ' : ';
                else
                    title = title + tooltipField2 + ' : ';

                title = title + row[tooltipField2];
            }

            if (tooltipField3 !== undefined && tooltipField3 !== '') {
                if (title.length > 0)
                    title = title + '<BR>';

                if (tooltipLabel3 !== undefined && tooltipLabel3 !== '')
                    title = title + tooltipLabel3 + ' : ';
                else
                    title = title + tooltipField3 + ' : ';

                title = title + row[tooltipField3];
            }

            if (tooltipField4 !== undefined && tooltipField4 !== '') {
                if (title.length > 0)
                    title = title + '<BR>';

                if (tooltipLabel4 !== undefined && tooltipLabel4 !== '')
                    title = title + tooltipLabel4 + ' : ';
                else
                    title = title + tooltipField4 + ' : ';

                title = title + row[tooltipField4];
            }
            return title;

        },
        clearPlottedCircularRegion: function () {
            if (CIRCULAR_REGION_UTIL.plottedCircularRegions.length > 0) {
                var circle = CIRCULAR_REGION_UTIL.plottedCircularRegions.pop();
                mmi_map.removeLayer(circle);
                CIRCULAR_REGION_UTIL.clearPlottedCircularRegion();
            }
        },
        clearPlottedCircularCenter: function () {
            if (CIRCULAR_REGION_UTIL.plottedCircularCenter.length > 0) {
                var circle = CIRCULAR_REGION_UTIL.plottedCircularCenter.pop();
                mmi_map.removeLayer(circle);
                CIRCULAR_REGION_UTIL.clearPlottedCircularCenter();
            }
        },
        setBoundToPlottedCircularRegion: function () {
            var latlngArr = [];
            for (var m in CIRCULAR_REGION_UTIL.plottedCircularRegions) {
                latlngArr.push(CIRCULAR_REGION_UTIL.plottedCircularRegions[m].getBounds().getCenter());
            }
            mmi_map.fitBounds(L.latLngBounds(latlngArr));
        },
        selectedRegionRows: [],
        setSelectedRegion: function (rowIndex) {

            var isMultiselect = thisWidget.properties['CircularRegionMultiSelect'];
            var selectedCircle = CIRCULAR_REGION_UTIL.plottedCircularRegions[rowIndex];

            var hasRegionFormatting = thisWidget.properties['CircularRegionFormatting'] !== undefined;
            var formatStyle = thisWidget.circularRegionStyle;
            if (hasRegionFormatting) {
                formatStyle = TW.getStyleFromStateFormatting({DataRow: selectedCircle.target.data, StateFormatting: thisWidget.properties['CircularRegionFormatting']});
            }
            var fillOpacity = thisWidget.getProperty('CircularRegionFillOpacity');


            if (selectedCircle !== undefined) {
                if (selectedCircle._isSelected) {
                    if (isMultiselect) {
                        TW.removeElementFromArray(CIRCULAR_REGION_UTIL.selectedRegionRows, rowIndex);
                        selectedCircle._isSelected = false;
                        selectedCircle.setStyle(
                                {"color": formatStyle.lineColor,
                                    "fillColor": formatStyle.backgroundColor,
                                    "weight": parseInt(formatStyle.lineThickness),
                                    "fillOpacity": fillOpacity}
                        );
                        thisWidget.updateSelection('CircularRegionData', CIRCULAR_REGION_UTIL.selectedRegionRows);
                    }
                } else {
                    if (!isMultiselect) {
                        CIRCULAR_REGION_UTIL.clearSelectedRegions();
                        CIRCULAR_REGION_UTIL.selectedRegionRows = [rowIndex];
                    }
                    else {
                        CIRCULAR_REGION_UTIL.selectedRegionRows.push(rowIndex);
                    }
                    selectedCircle.setStyle(
                            {"color": thisWidget.selectedCircularRegionStyle.lineColor,
                                "fillColor": thisWidget.selectedCircularRegionStyle.backgroundColor,
                                "weight": parseInt(thisWidget.selectedCircularRegionStyle.lineThickness),
                                "fillOpacity": fillOpacity}
                    );
                    selectedCircle._isSelected = true;
                    thisWidget.updateSelection('CircularRegionData', CIRCULAR_REGION_UTIL.selectedRegionRows);

                }
            }
        },
        clearSelectedRegions: function () {
            CIRCULAR_REGION_UTIL.selectedRegionRows = [];
            for (var r in CIRCULAR_REGION_UTIL.plottedCircularRegions) {
                var circle = CIRCULAR_REGION_UTIL.plottedCircularRegions[r];
                var fillOpacity = thisWidget.getProperty('CircularRegionFillOpacity');
                var hasRegionFormatting = thisWidget.properties['CircularRegionFormatting'] !== undefined;
                var formatStyle = thisWidget.circularRegionStyle;
                if (hasRegionFormatting) {
                    formatStyle = TW.getStyleFromStateFormatting({DataRow: circle.target.data, StateFormatting: thisWidget.properties['CircularRegionFormatting']});
                }
                circle.setStyle(
                        {"color": formatStyle.lineColor,
                            "fillColor": formatStyle.backgroundColor,
                            "weight": parseInt(formatStyle.lineThickness),
                            "fillOpacity": fillOpacity}
                );
                circle._isSelected = false;
            }
        }
    }

    var ROUTE_UTIL = {
        plottedRoute: undefined,
        plottedPlannedRoute: undefined,
        drawRoute: function (updatePropertyInfo) {
            var showRoute = thisWidget.getProperty('ShowRoute');

            if (showRoute) {

                if (ROUTE_UTIL.plottedRoute) {
                    mmi_map.removeLayer(ROUTE_UTIL.plottedRoute);
                }

                var dataRows = updatePropertyInfo.ActualDataRows;
                var locationField = thisWidget.getProperty('RouteLocationField');
                var LatLngList = [];

                for (var r in dataRows) {
                    var row = dataRows[r];
                    var thisLocation = row[locationField];
                    if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {
                        LatLngList.push([thisLocation.latitude, thisLocation.longitude]);
                    }
                }

                if (LatLngList.length > 1) {
                    ROUTE_UTIL.plottedRoute = new L.Polyline(LatLngList, {
                        color: thisWidget.routeStyle.lineColor,
                        weight: parseInt(thisWidget.routeStyle.lineThickness),
                        opacity: 1,
                        smoothFactor: 1
                    });

                    ROUTE_UTIL.plottedRoute.addTo(mmi_map);

                }

                if (LatLngList.length > 1) {
                    mmi_map.fitBounds(L.latLngBounds(LatLngList));
                } else {
                    if (LatLngList.length > 0) {
                        mmi_map.fitBounds(L.latLngBounds(LatLngList[0]));
                    }
                }
            }
        
            return;
        },
        drawPlannedRoute: function (updatePropertyInfo) {
            var showRoute = thisWidget.getProperty('ShowPlannedRoute');

            if (showRoute) {

                if (ROUTE_UTIL.plottedPlannedRoute) {
                    mmi_map.removeLayer(ROUTE_UTIL.plottedPlannedRoute);
                }

                var dataRows = updatePropertyInfo.ActualDataRows;
                var locationField = thisWidget.getProperty('PlannedRouteLocationField');
                var LatLngList = [];

                for (var r in dataRows) {
                    var row = dataRows[r];
                    var thisLocation = row[locationField];
                    if (thisLocation !== undefined && thisLocation.latitude !== 0.0 && thisLocation.longitude !== 0.0) {
                        LatLngList.push([thisLocation.latitude, thisLocation.longitude]);
                    }
                }

                if (LatLngList.length > 1) {
                    ROUTE_UTIL.plottedPlannedRoute = new L.Polyline(LatLngList, {
                        color: thisWidget.plannedRouteStyle.lineColor,
                        weight: parseInt(thisWidget.plannedRouteStyle.lineThickness),
                        opacity: 1,
                        smoothFactor: 1
                    });

                    ROUTE_UTIL.plottedPlannedRoute.addTo(mmi_map);

                }

                if (LatLngList.length > 1) {
                    mmi_map.fitBounds(L.latLngBounds(LatLngList));
                } else {
                    if (LatLngList.length > 0) {
                        mmi_map.fitBounds(L.latLngBounds(LatLngList[0]));
                    }
                }
            }
          
            return;
        },
        alertWindow: undefined,
        showAlert: function (text_) {

            if (ROUTE_UTIL.alertWindow) {
                ROUTE_UTIL.alertWindow.close();
            }
            
            
            var notifyLayout = thisWidget.getProperty('Notify_Layout');
            var notifyTimeout = thisWidget.getProperty('Notify_Timeout');
            if (notifyTimeout < 1) {
                notifyTimeout = false;
            }
            
            ROUTE_UTIL.alertWindow = new Noty({
                        type: 'error',
                        text: text_,
                        layout: notifyLayout,
                        theme: "mmi_custom",
                        progressBar: false,
                        timeout: notifyTimeout,
                        closeWith: ['click', 'button']
                    });

            ROUTE_UTIL.alertWindow.show();
        }

    }

	

    var MMI_API_UTIL = {

     appendStyle: function () {

            debugger;
            var success_bgcolor = "#f0f0f0";
            var error_bgcolor = "#f0f0f0";
            var normal_bgcolor = "#f0f0f0";
            var success_color = "#000";
            var error_color = "#000";
            var normal_color = "#000";
            var success_size = "11";
            var error_size = "11";
            var normal_size = "11";

            if (thisWidget.notify_Success_Style === undefined) {
                thisWidget.notify_Success_Style = new Object();
                TW.log.error('Style definition for success notification is missing.');
            }
            if (thisWidget.notify_Error_Style === undefined) {
                thisWidget.notify_Error_Style = new Object();
                TW.log.error('Style definition for error notification is missing.');
            }
            if (thisWidget.notify_Normal_Style === undefined) {
                thisWidget.notify_Normal_Style = new Object();
                TW.log.error('Style definition for normal notification is missing.');
            }

            if (thisWidget.notify_Success_Style.backgroundColor !== undefined && thisWidget.notify_Success_Style.backgroundColor !== "") {
                success_bgcolor = thisWidget.notify_Success_Style.backgroundColor;
            }
            if (thisWidget.notify_Error_Style.backgroundColor !== undefined && thisWidget.notify_Error_Style.backgroundColor !== "") {
                error_bgcolor = thisWidget.notify_Error_Style.backgroundColor;
            }
            if (thisWidget.notify_Normal_Style.backgroundColor !== undefined && thisWidget.notify_Normal_Style.backgroundColor !== "") {
                normal_bgcolor = thisWidget.notify_Normal_Style.backgroundColor;
            }

            if (thisWidget.notify_Success_Style.foregroundColor !== undefined && thisWidget.notify_Success_Style.foregroundColor !== "") {
                success_color = thisWidget.notify_Success_Style.foregroundColor;
            }
            if (thisWidget.notify_Error_Style.foregroundColor !== undefined && thisWidget.notify_Error_Style.foregroundColor !== "") {
                error_color = thisWidget.notify_Error_Style.foregroundColor;
            }
            if (thisWidget.notify_Normal_Style.foregroundColor !== undefined && thisWidget.notify_Normal_Style.foregroundColor !== "") {
                normal_color = thisWidget.notify_Normal_Style.foregroundColor;
            }

            if (thisWidget.notify_Success_Style.foregroundColor !== undefined && thisWidget.notify_Success_Style.foregroundColor !== "") {
                success_size = MMI_API_UTIL.parseFontSize(thisWidget.notify_Success_Style.textSize);
            }
            if (thisWidget.notify_Error_Style.foregroundColor !== undefined && thisWidget.notify_Error_Style.foregroundColor !== "") {
                error_size = MMI_API_UTIL.parseFontSize(thisWidget.notify_Error_Style.textSize);
            }
            if (thisWidget.notify_Normal_Style.foregroundColor !== undefined && thisWidget.notify_Normal_Style.foregroundColor !== "") {
                normal_size = MMI_API_UTIL.parseFontSize(thisWidget.notify_Normal_Style.textSize);
            }

            var css = document.createElement('style');
            css.type = 'text/css';

            var styles = '.noty_theme_mmi_custom.noty_bar {margin: 4px 0; overflow: hidden; position: relative; border: 1px solid transparent; border-radius: 4px;}'
                    + ' .noty_theme__mmi_custom.noty_bar .noty_body { padding: 15px; }'
                    + ' .noty_theme__mmi_custom.noty_bar .noty_buttons { padding: 10px; }'
                    + ' .noty_theme__mmi_custom.noty_bar .noty_close_button { font-size: 21px; font-weight: 700; line-height: 1; color: #000; text-shadow: 0 1px 0 #fff; filter: alpha(opacity=20); opacity: .2; background: transparent; }'
                    + ' .noty_theme__mmi_custom.noty_bar .noty_close_button:hover { background: transparent; text-decoration: none; opacity: .5; }'
                    + ' .noty_theme__mmi_custom.noty_type__success { background-color: ' + success_bgcolor + '; color: ' + success_color + '; font-size:' + success_size + '}'
                    + ' .noty_theme__mmi_custom.noty_type__error { background-color: ' + error_bgcolor + '; color:' + error_color + '; font-size:' + error_size + '}'
                    + ' .noty_theme__mmi_custom.noty_type__alert { background-color: ' + normal_bgcolor + '; color:' + normal_color + '; font-size:' + normal_size + '}'


            if (css.styleSheet)
                css.styleSheet.cssText = styles;
            else
                css.appendChild(document.createTextNode(styles));
            document.getElementsByTagName("head")[0].appendChild(css);
        },
        parseFontSize : function(size_){
            var v = "11";
            if(size_ && size_ !== "") {
                if(size_ === "xsmall")
                    v = "9px";
                else if(size_ === "small")
                    v = "10px";
                else if(size_ === "normal")
                    v = "11px";
                else if(size_ === "large")
                    v = "12px";
                else if(size_ === "xlarge")
                    v = "14px";
                else if(size_ === "xxl")
                    v = "16px";
                else if(size_ === "2xl")
                    v = "18px";
                else if(size_ === "3xl")
                    v = "22px";
                else
                    v = size_;
                return v;
                
            }
                            
            
        }
    }
 


};
