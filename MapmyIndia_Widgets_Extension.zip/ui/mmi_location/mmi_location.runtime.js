TW.Runtime.Widgets.mmi_location = function () {
    var thisWidget = this;
    this.DEFAULT_ZOOM = 3;
    var defaultValue = undefined;
    this.mapOpen = false;
    this.mapEl = undefined;

    this.map = undefined;
    this.mapMarker = undefined;

    this.haveMmiMaps = false;
    var defaultZoom = 10;

    this.renderHtml = function () {
        var html = '<div class="widget-content widget-location widget-mmi-location-picker" >' +
                '<div class="coreLocationPicker">' +
                '<label>Longitude</label>' +
                '<input class="longitudeField" type="text" value="' + ((this.getProperty('Longitude') !== undefined) ? this.getProperty('Longitude') : '') + '" tabindex="' + thisWidget.getProperty('TabSequence') + '"></input>\n\
                  <p class="longitudeFieldMsg"></p>' +
                '<label>Latitude</label>' +
                '<input class="latitudeField" type="text" value="' + ((this.getProperty('Latitude') !== undefined) ? this.getProperty('Latitude') : '') + '" tabindex="' + thisWidget.getProperty('TabSequence') + '"></input>\n\
                <p class="latitudeFieldMsg"></p>' +
                (this.getProperty('ShowElevation') === true ? '<label>Elevation</label><input class="elevationField" type="text" value="' + ((this.getProperty('Elevation') !== undefined) ? this.getProperty('Elevation') : '') + '" tabindex="' + thisWidget.getProperty('TabSequence') + '"></input>' : '') +
                (this.getProperty('ShowUnits') === true ? '<label>Units</label><p>WGS84</p>' : '') +
                '</div>';

        try {
            if (MapmyIndia !== undefined && MapmyIndia !== null) {
                this.haveMmiMaps = true;
            }
        }
        catch (errmsg) {
        }

        if (this.haveMmiMaps) {
            html = html + (this.getProperty('UseMap') === true ? '<div class="locationMapButton"><span>Map</span></div>' : '');
        }

        html = html + '</div>';
        return html;
    };

    this.afterRender = function () {
        var domElementId = this.jqElementId;
        var widgetElement = this.jqElement;
        var widgetProperties = this.properties;
        var widgetReference = this;

        var formatResult = TW.getStyleFromStyleDefinition(widgetReference.getProperty('Style', 'DefaultGoogleLocationStyle'));

        var cssMmiLocationBackground = TW.getStyleCssGradientFromStyle(formatResult);
        var cssMmiLocationText = TW.getStyleCssTextualNoBackgroundFromStyle(formatResult);
        var cssMmiLocationBorder = TW.getStyleCssBorderFromStyle(formatResult);

        thisWidget.markerStyle = TW.getStyleFromStyleDefinition(thisWidget.getProperty('Style'));

        var styleBlock =
                '<style>' +
                '#' + widgetReference.jqElementId + '{' + cssMmiLocationBackground + cssMmiLocationBorder + cssMmiLocationText + '}' +
                '</style>';

        $(styleBlock).prependTo(widgetElement);


        var locationMapId = domElementId + '-location-map';

        if (widgetReference.haveMmiMaps) {

            $('body').append('<div id="' + locationMapId + '" class="locationMap mmi-widget-loc-map"  style="display:none;position:absolute;height:' + this.getProperty('MapHeight') + 'px;width:' + this.getProperty('MapWidth') + 'px;"> ' + /* */ + ' </div>');
            this.mapEl = $('#' + locationMapId);
            this.mapEl.css('z-index', 20000);

            widgetElement.find('.locationMapButton').bind('click', function () {
                var locationPickerOffset = widgetElement.offset();
                if (widgetReference.mapOpen === true) {
                    widgetReference.mapOpen = false;
                    widgetReference.mapEl.hide();
                } else {
                    widgetReference.mapEl.show();
                    widgetReference.mapEl.css('top', (locationPickerOffset.top + widgetElement.outerHeight()) + 'px');
                    widgetReference.mapEl.css('left', locationPickerOffset.left + 'px');
                    widgetReference.configureAndDisplayMap();
                    widgetReference.mapOpen = true;
                }

            });
        }


        var latitudeField = widgetElement.find('.latitudeField');
        var longitudeField = widgetElement.find('.longitudeField');
        latitudeField.change(function (event) {
            debugger
            if (thisWidget.defaultMarker) {
                thisWidget.map.removeLayer(thisWidget.defaultMarker);
            }
            widgetReference.setProperty('Latitude', latitudeField.val());
            var newLatLocation = null;
            if (widgetProperties['Location'] !== undefined) {
                newLatLocation = widgetProperties['Location'];
            } else {
                newLatLocation = new Object();
                newLatLocation.longitude = widgetProperties['Longitude'];
            }
            newLatLocation.latitude = latitudeField.val();


            if (event.currentTarget === latitudeField.get(0)) {
                if (TW.isNumber(latitudeField.val())) {

                    var valid = MMI_API_UTIL.validateCoordiante(newLatLocation.latitude, newLatLocation.longitude);
                    thisWidget.setProperty('isValidCoordinate', valid);
                    widgetReference.setProperty('Location', newLatLocation);
                    widgetElement.find('.latitudeFieldMsg').text("");
                    if (!valid) {
                        thisWidget.setProperty('isValidCoordinate', false);
                        if (!MMI_API_UTIL.validateCoordiante(latitudeField.val(), 0)) {
                            widgetElement.find('.latitudeFieldMsg').text("Invalid latutide value.");
                        } else {
                            widgetElement.find('.latitudeFieldMsg').text("");
                        }
                        if (!MMI_API_UTIL.validateCoordiante(0, longitudeField.val())) {
                            widgetElement.find('.longitudeFieldMsg').text("Invalid longitude value.");
                        } else {
                            widgetElement.find('.longitudeFieldMsg').text("");
                        }
                    }
                    if (widgetReference.haveMmiMaps && valid) {
                     
                        thisWidget.plotMarker(newLatLocation.latitude, newLatLocation.longitude, thisWidget.markerStyle.image);
                        var zoom_ = defaultZoom;
                        if (thisWidget.map.getZoom() > defaultZoom) {
                            zoom_ = thisWidget.map.getZoom();
                        }
                        thisWidget.map.setView([newLatLocation.latitude, newLatLocation.longitude], zoom_);

                    }
                } else {
                    widgetElement.find('.latitudeFieldMsg').text("Invalid latutide value.");
                    thisWidget.setProperty('isValidCoordinate', false);
                    TW.log.info('mmilocation: afterrender: latitude change handler: user entered invalid data: \'' + latitudeField.val() + '\' resetting to previous value');
//                    latitudeField.val(widgetProperties['Latitude']);
                }
            }
        });



        longitudeField.change(function (event) {
            debugger

            if (thisWidget.defaultMarker) {
                thisWidget.map.removeLayer(thisWidget.defaultMarker);
            }

            widgetReference.setProperty('Longitude', longitudeField.val());

            var newLngLocation = null;
            if (widgetProperties['Location'] !== undefined) {
                newLngLocation = widgetProperties['Location'];
            } else {
                newLngLocation = new Object();
                newLngLocation.latitude = widgetProperties['Latitude'];
            }

            newLngLocation.longitude = longitudeField.val();
            widgetReference.setProperty('Location', newLngLocation);

            if (event.currentTarget === longitudeField.get(0)) {
                if (TW.isNumber(longitudeField.val())) {


                    var valid = MMI_API_UTIL.validateCoordiante(newLngLocation.latitude, newLngLocation.longitude);
                    thisWidget.setProperty('isValidCoordinate', valid);
                    widgetElement.find('.longitudeFieldMsg').text("");
                    if (!valid) {
                        thisWidget.setProperty('isValidCoordinate', false);
                        if (!MMI_API_UTIL.validateCoordiante(latitudeField.val(), 0)) {
                            widgetElement.find('.latitudeFieldMsg').text("Invalid latutide value.");
                        } else {
                            widgetElement.find('.latitudeFieldMsg').text("");
                        }
                        if (!MMI_API_UTIL.validateCoordiante(0, longitudeField.val())) {
                            widgetElement.find('.longitudeFieldMsg').text("Invalid longitude value.");
                        } else {
                            widgetElement.find('.longitudeFieldMsg').text("");
                        }
                    }

                    if (widgetReference.haveMmiMaps && valid) {
                      
                        thisWidget.plotMarker(newLngLocation.latitude, newLngLocation.longitude, thisWidget.markerStyle.image);
                        var zoom_ = defaultZoom;
                        if (thisWidget.map.getZoom() > defaultZoom) {
                            zoom_ = thisWidget.map.getZoom();
                        }
                        thisWidget.map.setView([newLngLocation.latitude, newLngLocation.longitude], zoom_);
                    }

                } else {
                    thisWidget.setProperty('isValidCoordinate', false);
                    widgetElement.find('.longitudeFieldMsg').text("Invalid longitude value.");
                    TW.log.info('mmilocation: afterrender: longitude change handler: user entered invalid data: \'' + longitudeField.val() + '\' resetting to previous value');
//                    latitudeField.val(widgetProperties['Latitude']);
                }
            }
        });


        var elevationField = widgetElement.find('.elevationField');
        elevationField.change(function (event) {
            if (event.currentTarget === elevationField.get(0)) {
                if (TW.isNumber(elevationField.val())) {
                    widgetReference.setProperty('Elevation', elevationField.val());

                    if (widgetProperties['Location'] !== undefined) {
                        var newEleLocation = widgetProperties['Location'];

                        newEleLocation.elevation = elevationField.val();

                        widgetReference.setProperty('Location', newEleLocation);
                    }
                } else {
                    TW.log.info('mmilocation: afterrender: elevation change handler: user entered invalid data: \'' + elevationField.val() + '\' resetting to previous value');
                    elevationField.val(widgetProperties['Latitude']);
                }
            }
        });
        

    };


    this.configureAndDisplayMap = function () {

        var mapDiv = this.mapEl;
        var widgetProperties = this.properties;
        var widgetReference = this;

        var defaultLocation = {'latitude': '', 'longitude': ''};
        var valid = false;
        if (widgetProperties['Location'] !== undefined) {

            valid = MMI_API_UTIL.validateCoordiante(widgetProperties['Location']['latitude'], widgetProperties['Location']['longitude']);
            thisWidget.setProperty('isValidCoordinate', valid);
            if (valid) {
                defaultLocation.latitude = widgetProperties['Location']['latitude'];
                defaultLocation.longitude = widgetProperties['Location']['longitude'];
            }


        } else if (widgetProperties['Latitude'] !== undefined && widgetProperties['Latitude'] !== '' &&
                widgetProperties['Longitude'] !== undefined && widgetProperties['Longitude'] !== '') {

            valid = MMI_API_UTIL.validateCoordiante(widgetProperties['Latitude'], widgetProperties['Longitude']);
            thisWidget.setProperty('isValidCoordinate', valid);
            if (valid) {
                defaultLocation.latitude = widgetProperties['Latitude'];
                defaultLocation.longitude = widgetProperties['Longitude'];
            }

        }


        if (thisWidget.map === undefined) {
            thisWidget.map = new MapmyIndia.Map(mapDiv.get(0), {
                center: [28.63275, 77.21947],
                zoomControl: true,
                hybrid: false,
                search: false,
                location: false
            }).setView([28.63275, 77.21947], 5);

            registerClickEvent();
            thisWidget.map.doubleClickZoom.disable();
		
        }

        if (widgetProperties['Location'] !== undefined && valid) {
            thisWidget.plotMarker(defaultLocation.latitude, defaultLocation.longitude, thisWidget.markerStyle.image);
          
            var zoom_ = defaultZoom;
            if (thisWidget.map.getZoom() > defaultZoom) {
                zoom_ = thisWidget.map.getZoom();
            }
            thisWidget.map.setView([defaultLocation.latitude, defaultLocation.longitude], zoom_);

        } else if (widgetProperties['Latitude'] !== undefined && widgetProperties['Latitude'] !== '' &&
                widgetProperties['Longitude'] !== undefined && widgetProperties['Longitude'] !== '' && valid) {
            thisWidget.plotMarker(defaultLocation.latitude, defaultLocation.longitude, thisWidget.markerStyle.image);
          
            var zoom_ = defaultZoom;
            if (thisWidget.map.getZoom() > defaultZoom) {
                zoom_ = thisWidget.map.getZoom();
            }
            thisWidget.map.setView([defaultLocation.latitude, defaultLocation.longitude], zoom_);
        }

        try {
            if (thisWidget.map) {
                thisWidget.map.invalidateSize();
            }
        } catch (err) {
        }
    };
    thisWidget.defaultMarker = undefined;
    this.plotMarker = function (lat, lng, imageIcon, label, html) {

        if (thisWidget.defaultMarker) {
            thisWidget.map.removeLayer(thisWidget.defaultMarker);
        }

        var myIcon = L.icon({
            iconUrl: imageIcon,
            iconRetinaUrl: imageIcon,
            iconSize: [35, 35],
            iconAnchor: [20, 10]
        });
        var marker = L.marker([lat, lng], {
            icon: myIcon,
            title: 'Location Marker'
        });
        marker.addTo(thisWidget.map);
        thisWidget.defaultMarker = marker;
        return marker;
    }
	
	
	function registerClickEvent(){
		var lastClickTime = 0;
            thisWidget.map.on('click', function (event) {
                var thisClickTime = (new Date).getTime();
                if (thisClickTime - lastClickTime < 500) {
                    
                    thisWidget.setProperty('isValidCoordinate', MMI_API_UTIL.validateCoordiante(event.latlng.lat, event.latlng.lng));
                    
                }
                lastClickTime = thisClickTime;
            });
	}

    this.updateProperty = function (updatePropertyInfo) {

        var widgetElement = this.jqElement;
        var widgetReference = this;

        if (thisWidget.defaultMarker) {
            thisWidget.map.removeLayer(thisWidget.defaultMarker);
        }

        if (updatePropertyInfo.TargetProperty === 'Location' && updatePropertyInfo.RawSinglePropertyValue !== undefined) {
            var location = updatePropertyInfo.RawSinglePropertyValue;
            //The latitude must be a number between -90 and 90 and the longitude between -180 and 180.
            thisWidget.setProperty('isValidCoordinate', MMI_API_UTIL.validateCoordiante(location.latitude, location.latitude));
            this.setMyLocation(location);
            if (widgetReference.mapOpen !== undefined && widgetReference.mapOpen === true) {
                widgetReference.mapOpen = false;
                widgetReference.mapEl.hide();
            }
            widgetElement.val(updatePropertyInfo.RawSinglePropertyValue);
        } else if (updatePropertyInfo.TargetProperty === 'Location') {
            this.resetInputToDefault();
        }
    };


    this.setMyLocation = function (location) {
        var domElementId = this.jqElementId;
        var widgetElement = this.jqElement;
        var widgetProperties = this.properties;
        var widgetReference = this;

        if (location !== undefined && location !== null) {
            if (location.latitude != undefined && location.longitude != undefined) {

                widgetReference.setProperty('Latitude', location.latitude);
                widgetElement.find('.latitudeField').val(location.latitude);

                widgetReference.setProperty('Longitude', location.longitude);
                widgetElement.find('.longitudeField').val(location.longitude);

                if (location.elevation !== undefined) {
                    widgetReference.setProperty('Elevation', location.elevation);
                    widgetElement.find('.elevationField').val(location.elevation);
                } else {
                    location.elevation = 0;
                }

                if (location.units === undefined) {
                    location.units = 'WGS84';
                }

                widgetReference.setProperty('Location', location);

            }
        }
    };

    this.resetInputToDefault = function () {
        var widgetElement = this.jqElement;
        widgetElement.find('.longitudeField').val(defaultValue === undefined ? '' : defaultValue);
        widgetElement.find('.latitudeField').val(defaultValue === undefined ? '' : defaultValue);

        thisWidget.setProperty('Longitude', defaultValue);
        thisWidget.setProperty('Latitude', defaultValue);
        thisWidget.setProperty('Location', defaultValue);

        thisWidget.setProperty('Elevation', defaultValue);
        widgetElement.find('.elevationField').val(defaultValue === undefined ? '' : defaultValue);

        if (thisWidget.mapOpen !== undefined && thisWidget.mapOpen === true) {
            thisWidget.mapOpen = false;
            thisWidget.mapEl.hide();
        }

    };

    this.beforeDestroy = function () {
        if (thisWidget.map != null) {
            thisWidget.map.remove();
            thisWidget.map = null;
        }
        if (thisWidget.mapOpen !== undefined && thisWidget.mapOpen === true) {
            thisWidget.mapOpen = false;
            thisWidget.mapEl.hide();
        }

        $(".as-results").remove();
        $(".as-values").remove();

    };

   var MMI_API_UTIL = {

        validateCoordiante: function (lat, lng) {
            //The latitude must be a number between -90 and 90 and the longitude between -180 and 180.
            var flag = false;
            if (lat !== undefined && !isNaN(lat) && lat.toString().trim().length > 0
                    && parseFloat(lat) > -90 && parseFloat(lat) < 90) {

                if (lng !== undefined && !isNaN(lng) && lng.toString().trim().length > 0
                        && parseFloat(lng) > -180 && parseFloat(lng) < 180) {
                    flag = true;
                }
            }
            return flag;
        },

         
    }
  

};